let domainInput;
let apiKeyInput;
let btnVerify;
let validationMessageDiv;

let verified = false;
let savedConfigs = {};

document.onreadystatechange = function () {
  if (document.readyState === "interactive") renderApp();
};

async function renderApp() {
  try {
    const client = await app.initialized();
    window.client = client;

    domainInput = document.getElementById("domain");
    apiKeyInput = document.getElementById("apiKey");
    btnVerify = document.getElementById("btnVerify");
    validationMessageDiv = document.getElementById("validationMessage");

    await Promise.all([
      customElements.whenDefined("fw-input"),
      customElements.whenDefined("fw-button"),
    ]);

    await new Promise((resolve) => setTimeout(resolve, 100));

    btnVerify.addEventListener("fwClick", verify);

    domainInput.addEventListener("fwInput", () => {
      verified = false;
    });
    apiKeyInput.addEventListener("fwInput", () => {
      verified = false;
    });
  } catch (error) {
    console.error("Error initializing app:", error);
  }
}

function getBasicAuth(apiKey) {
  return btoa(`${apiKey}:X`);
}

async function verify() {
  try {
    showValidationMessage("Verifying credentials...", "validating");

    let domain = domainInput.value.trim().replace(/^https?:\/\//, "").replace(/\/$/, "");
    const apiKey = apiKeyInput.value.trim();
    const isKeyUnchanged =
      savedConfigs && savedConfigs.api_key && apiKey === savedConfigs.api_key;

    if (!domain) {
      showValidationMessage("Please enter domain.", "error");
      verified = false;
      return;
    }

    if (!domain.includes(".freshdesk.com")) {
      domain = `${domain}.freshdesk.com`;
    }

    if (isKeyUnchanged) {
      if (domain !== savedConfigs.domain) {
        showValidationMessage("Enter API Key to verify the updated domain.", "error");
        verified = false;
        return;
      }

      verified = true;
      showValidationMessage("API Key already saved. Enter a new key to re-verify.", "success");
      return;
    }

    if (!apiKey) {
      showValidationMessage("Please enter API Key to verify credentials.", "error");
      verified = false;
      return;
    }

    const res = await client.request.invokeTemplate("verify_freshdesk_credentials", {
      context: {
        domain,
        encoded_auth: getBasicAuth(apiKey),
      },
    });

    if (res.status === 200) {
      verified = true;
      showValidationMessage("Verified successfully!", "success");
    } else {
      verified = false;
      showValidationMessage(
        "Verification failed: Could not verify credentials. Please check your domain and API key.",
        "error"
      );
    }
  } catch (err) {
    verified = false;
    console.error("Verification error:", err);

    let errorMessage =
      "Could not verify credentials. Please check your domain and API key.";
    if (err.status === 401) {
      errorMessage = "Authentication failed. Please check your API key.";
    } else if (err.status === 404) {
      errorMessage = "Domain not found. Please check your Freshdesk domain.";
    } else if (err.status === 403) {
      errorMessage = "Access denied. Please check the API key permissions.";
    } else if (!err.status && err.message) {
      errorMessage = "Could not connect to Freshdesk. Please check the domain.";
    }

    showValidationMessage(`Verification failed: ${errorMessage}`, "error");
  }
}

function showValidationMessage(message, type) {
  validationMessageDiv.textContent = message;
  validationMessageDiv.style.display = "block";
  validationMessageDiv.className = "validation-message";

  if (type === "success") {
    validationMessageDiv.classList.add("validation-success");
  } else if (type === "error") {
    validationMessageDiv.classList.add("validation-error");
  }
}

function postConfigs() {
  let encodedApiKey;
  const newKeyInput = apiKeyInput.value.trim();
  const isKeyUnchanged =
    savedConfigs.api_key && newKeyInput === savedConfigs.api_key;

  if (newKeyInput && !isKeyUnchanged) {
    encodedApiKey = getBasicAuth(newKeyInput);
  } else {
    encodedApiKey = savedConfigs.api_key;
  }

  return {
    __meta: {
      secure: ["api_key"],
    },
    domain: domainInput.value.trim().replace(/^https?:\/\//, "").replace(/\/$/, ""),
    api_key: encodedApiKey,
  };
}

function getConfigs(configs) {
  savedConfigs = configs || {};

  domainInput.value = configs.domain || "";

  if (configs.api_key) {
    apiKeyInput.value = configs.api_key;
    verified = true;
  } else {
    apiKeyInput.value = "";
  }
}

async function validate() {
  const domain = domainInput.value.trim();
  const key = apiKeyInput.value.trim();

  if (!domain) {
    showValidationMessage("Domain is required.", "error");
    return false;
  }

  if (!key) {
    showValidationMessage("API Key is required.", "error");
    return false;
  }

  if (!verified) {
    showValidationMessage("Please verify your credentials before saving.", "error");
    return false;
  }

  return true;
}
