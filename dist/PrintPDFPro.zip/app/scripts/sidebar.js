let client;

let state = {
  ticketId: null,
  templates: [],
  generating: false,
};

document.addEventListener("DOMContentLoaded", init);

async function init() {
  try {
    client = await app.initialized();
    client.events.on("app.activated", function () {
      loadTemplates({ silent: true });
    });

    let ticketData = await client.data.get("ticket");
    state.ticketId = ticketData.ticket.id;

    bindEvents();
    await loadTemplates();

    document.getElementById("sidebarLoading").classList.add("hidden");
    document.getElementById("sidebarMain").classList.remove("hidden");
  } catch (error) {
    console.error("Print Tickets PDF init failed:", error);
    document.getElementById("sidebarLoading").textContent = "Failed to load. Please refresh.";
  }
}

function bindEvents() {
  document.getElementById("btnGenerate").addEventListener("click", onGeneratePdf);
  bindTemplateInfo();
}

function bindTemplateInfo() {
  let info = document.getElementById("templateInfo");
  let trigger = document.getElementById("templateInfoBtn");
  if (!info || !trigger) return;

  trigger.addEventListener("click", function (event) {
    event.stopPropagation();
    setTemplateInfoOpen(!info.classList.contains("is-open"));
  });

  document.addEventListener("click", function (event) {
    if (!info.contains(event.target)) {
      setTemplateInfoOpen(false);
    }
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") {
      setTemplateInfoOpen(false);
    }
  });
}

function setTemplateInfoOpen(isOpen) {
  let info = document.getElementById("templateInfo");
  let trigger = document.getElementById("templateInfoBtn");
  if (!info || !trigger) return;

  info.classList.toggle("is-open", isOpen);
  trigger.setAttribute("aria-expanded", isOpen ? "true" : "false");
}

async function loadTemplates() {
  try {
    let response = await client.request.invoke("listTemplates", {});
    let payload = parseInvokeResponse(response);
    if (!payload || !payload.success) {
      throw new Error(resolveInvokeError(payload) || "Failed to load templates.");
    }

    state.templates = Array.isArray(payload.templates) ? payload.templates : [];
    renderTemplateSelector();
  } catch (error) {
    console.error("Failed to load templates:", error);
  }
}

function renderTemplateSelector() {
  let select = document.getElementById("templateSelect");
  let currentValue = select.value || "__default__";
  let options = ['<option value="__default__">Default</option>'];

  state.templates.forEach(function (template) {
    options.push('<option value="' + escapeHtml(template.id) + '">' + escapeHtml(template.name) + '</option>');
  });

  select.innerHTML = options.join("");

  let isStillAvailable = state.templates.some(function (template) {
    return template.id === currentValue;
  });
  select.value = isStillAvailable ? currentValue : "__default__";
}

async function onGeneratePdf() {
  if (state.generating) return;
  state.generating = true;

  let btn = document.getElementById("btnGenerate");
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-sm"></span>Generating...';

  try {
    let args = { ticket_id: state.ticketId };
    let templateId = document.getElementById("templateSelect").value;
    if (templateId && templateId !== "__default__") {
      args.template_id = templateId;
    }

    let response = await client.request.invoke("createTicketPdfExport", args);
    let payload = parseInvokeResponse(response);
    if (!payload || !payload.success) {
      throw new Error(resolveInvokeError(payload) || "Failed to generate PDF.");
    }

    if (payload.base64_data) {
      triggerDownload(
        payload.base64_data,
        payload.file_name || ("ticket-" + state.ticketId + ".pdf"),
        payload.mime_type || "application/pdf"
      );
      notify("success", "PDF generated and downloading.");
    } else {
      notify("success", "PDF created. Download it from the dashboard.");
    }
  } catch (error) {
    console.error("PDF generation failed:", error);
    notify("error", resolveErrorMessage(error, "Failed to generate PDF."));
  } finally {
    state.generating = false;
    btn.disabled = false;
    btn.textContent = "Generate PDF";
  }
}

function triggerDownload(base64Data, fileName, mimeType) {
  let binary = atob(String(base64Data || ""));
  let bytes = new Uint8Array(binary.length);

  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }

  let blob = new Blob([bytes], { type: mimeType });
  let objectUrl = URL.createObjectURL(blob);
  let link = document.createElement("a");
  link.href = objectUrl;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(objectUrl);
}

function parseInvokeResponse(result) {
  if (!result) return null;
  if (typeof result === "string") {
    try { return JSON.parse(result); } catch { return null; }
  }
  if (typeof result.response === "string") {
    try { return JSON.parse(result.response); } catch { return null; }
  }
  if (result.response && typeof result.response === "object") {
    return result.response;
  }
  return typeof result === "object" ? result : null;
}

function resolveInvokeError(payload) {
  if (!payload) return "";
  return payload.message || payload.detail || (payload.error && payload.error.message) || "";
}

function resolveErrorMessage(error, fallback) {
  if (error && error.message) return error.message;
  return fallback;
}

function notify(type, message) {
  let notifyType = type === "error" ? "danger" : type;
  client.interface.trigger("showNotify", { type: notifyType, message: message });
}

function escapeHtml(text) {
  let div = document.createElement("div");
  div.textContent = text === null || text === undefined ? "" : String(text);
  return div.innerHTML;
}
