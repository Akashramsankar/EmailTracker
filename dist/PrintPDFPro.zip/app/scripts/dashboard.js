let client;

const HISTORY_PAGE_SIZE = 10;
const SEARCH_PAGE_SIZE = 30;
const INVOKE_TIMEOUT_MS = 15000;
const SEARCH_INVOKE_TIMEOUT_MS = 30000;
const EXPORT_INVOKE_TIMEOUT_MS = 180000;
const ZIP_MEMBER_EXPORT_MAX_ATTEMPTS = 3;
const ZIP_MEMBER_EXPORT_RETRY_DELAY_MS = 1500;
const ZIP_MEMBER_EXPORT_GAP_MS = 250;

let zipCrc32Table = null;

const DEFAULT_SECTION_ORDER = ["header", "details", "custom_fields", "description", "conversations"];

let state = {
  activeTab: "history",
  // History tab
  exports: [],
  exportsLoading: false,
  historyPage: 1,
  // History refresh coordination
  historyLoadInFlight: false,
  historyLoadQueued: false,
  historyQueuedSilent: true,
  historyRequestId: 0,
  // Bulk tab
  searchResults: [],
  searchTotal: 0,
  searchPage: 1,
  searchLoading: false,
  selectedTicketIds: new Set(),
  bulkExporting: false,
  templates: [],
  fieldDefinitions: [],
  customFields: [],
  bulkTicketLimit: 10,
  currentEditorTemplate: null,
  editorSectionOrder: DEFAULT_SECTION_ORDER.slice(),
  individualPrintingIds: new Set(),
  searchPerformed: false,
  // Templates refresh coordination
  templatesLoadInFlight: false,
  templatesLoadQueued: false,
  templatesQueuedSilent: true,
  templatesRequestId: 0,
};

const SECTION_LABELS = {
  header: "Header",
  details: "Details",
  custom_fields: "Custom Fields",
  description: "Description",
  conversations: "Conversations",
};

document.addEventListener("DOMContentLoaded", init);

async function init() {
  try {
    client = await app.initialized();
    client.events.on("app.activated", function () {
      loadExportHistory({ silent: true });
      loadTemplates({ silent: true });
    });

    bindEvents();
    updateBulkExportButtonLabel();
    await Promise.all([loadExportHistory(), loadTemplates(), loadFieldDefinitions()]);
  } catch (error) {
    console.error("Dashboard init failed:", error);
    notify("error", "Unable to initialize the dashboard.");
  }
}

function bindEvents() {
  // Tab switching
  document.querySelectorAll(".tab-btn").forEach(function (btn) {
    btn.addEventListener("click", function () {
      switchTab(btn.getAttribute("data-tab"));
    });
  });

  // History tab
  document.getElementById("refreshExportsBtn").addEventListener("click", function () {
    loadExportHistory();
  });

  // Bulk tab - Search
  document.getElementById("btnSearch").addEventListener("click", function () {
    state.searchPage = 1;
    searchTickets();
  });
  document.getElementById("btnClearFilters").addEventListener("click", clearFilters);

  // Bulk tab - Selection
  document.getElementById("btnSelectAll").addEventListener("click", selectAll);
  document.getElementById("btnDeselectAll").addEventListener("click", deselectAll);
  document.getElementById("selectAllCb").addEventListener("change", function (e) {
    if (e.target.checked) {
      selectAll();
    } else {
      deselectAll();
    }
  });

  // Bulk tab - Export
  document.getElementById("btnBulkExport").addEventListener("click", bulkExportSelected);
  document.getElementById("bulkFormatSelect").addEventListener("change", updateBulkExportButtonLabel);

  // Template manager
  document.querySelectorAll(".template-panel-header").forEach(function (header) {
    header.addEventListener("click", function () {
      header.classList.toggle("open");
    });
  });
  document.getElementById("editorTemplateSelect").addEventListener("change", onEditorTemplateSelect);
  document.getElementById("btnEditorSaveTemplate").addEventListener("click", onEditorSaveTemplate);
  document.getElementById("btnEditorSaveAsTemplate").addEventListener("click", openEditorSaveAsModal);
  document.getElementById("btnEditorDeleteTemplate").addEventListener("click", openEditorDeleteModal);
  document.getElementById("btnEditorSaveAsCancel").addEventListener("click", closeEditorSaveAsModal);
  document.getElementById("btnEditorSaveAsConfirm").addEventListener("click", onEditorSaveAsConfirm);
  document.getElementById("editorSaveAsModal").addEventListener("click", function (event) {
    if (event.target.id === "editorSaveAsModal") {
      closeEditorSaveAsModal();
    }
  });
  document.getElementById("btnEditorDeleteCancel").addEventListener("click", closeEditorDeleteModal);
  document.getElementById("btnEditorDeleteConfirm").addEventListener("click", onEditorDeleteConfirm);
  document.getElementById("editorDeleteModal").addEventListener("click", function (event) {
    if (event.target.id === "editorDeleteModal") {
      closeEditorDeleteModal();
    }
  });
  document.querySelectorAll('input[name="tplViewMode"]').forEach(function (radio) {
    radio.addEventListener("change", syncEditorViewModeState);
  });

  // Enter key on search fields
  document.querySelectorAll(".filter-field input").forEach(function (input) {
    input.addEventListener("keydown", function (e) {
      if (e.key === "Enter") {
        state.searchPage = 1;
        searchTickets();
      }
    });
  });
}

// ── Tab switching ──────────────────────────────────────────────────────────────

function switchTab(tabName) {
  state.activeTab = tabName;

  document.querySelectorAll(".tab-btn").forEach(function (btn) {
    btn.classList.toggle("active", btn.getAttribute("data-tab") === tabName);
  });

  document.querySelectorAll(".tab-content").forEach(function (content) {
    content.classList.toggle("active", content.id === "tabContent" + capitalize(tabName));
  });
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// ── Export History ──────────────────────────────────────────────────────────────

async function loadExportHistory(options) {
  let silent = Boolean(options && options.silent);

  if (state.historyLoadInFlight) {
    state.historyLoadQueued = true;
    state.historyQueuedSilent = state.historyQueuedSilent && silent;
    return;
  }

  state.historyLoadInFlight = true;
  let nextSilent = silent;

  try {
    do {
      state.historyLoadQueued = false;
      state.historyQueuedSilent = true;
      await performHistoryLoad({ silent: nextSilent });
      nextSilent = state.historyQueuedSilent;
    } while (state.historyLoadQueued);
  } finally {
    state.historyLoadInFlight = false;
  }
}

async function performHistoryLoad(options) {
  let silent = Boolean(options && options.silent);
  let requestId = ++state.historyRequestId;

  state.exportsLoading = true;
  if (!silent) renderHistoryTab();

  try {
    let response = await invokeWithTimeoutRetryingOnce("getTicketPdfDashboardData", {});

    if (requestId !== state.historyRequestId) return;

    let payload = parseInvokeResponse(response);

    if (!payload || payload.success === false) {
      throw new Error(resolveInvokeError(payload) || "Unable to load print history.");
    }

    state.exports = Array.isArray(payload.exports) ? payload.exports : [];
    if (payload.limits && Number(payload.limits.bulk_ticket_max) > 0) {
      state.bulkTicketLimit = Number(payload.limits.bulk_ticket_max);
    }
  } catch (error) {
    if (requestId !== state.historyRequestId) return;
    console.error("Failed to load export history:", error);
    if (!silent) notify("error", resolveErrorMessage(error, "Unable to load print history."));
  } finally {
    if (requestId === state.historyRequestId) {
      state.exportsLoading = false;
      renderHistoryTab();
      updateSelectionCount();
    }
  }
}

function renderHistoryTab() {
  let loadingEl = document.getElementById("historyLoading");
  let table = document.getElementById("historyTable");
  let emptyEl = document.getElementById("historyEmpty");
  let tbody = document.getElementById("historyTableBody");
  let paginationEl = document.getElementById("historyPagination");
  let refreshBtn = document.getElementById("refreshExportsBtn");

  refreshBtn.disabled = state.exportsLoading;
  refreshBtn.innerHTML = state.exportsLoading
    ? '<span class="spinner"></span>Refreshing'
    : "Refresh Print History";

  if (state.exportsLoading) {
    loadingEl.classList.remove("hidden");
    table.classList.add("hidden");
    emptyEl.classList.add("hidden");
    paginationEl.classList.add("hidden");
    return;
  }

  loadingEl.classList.add("hidden");

  if (!state.exports.length) {
    table.classList.add("hidden");
    emptyEl.classList.remove("hidden");
    paginationEl.classList.add("hidden");
    return;
  }

  let totalPages = Math.ceil(state.exports.length / HISTORY_PAGE_SIZE);
  if (state.historyPage > totalPages) state.historyPage = totalPages;
  let start = (state.historyPage - 1) * HISTORY_PAGE_SIZE;
  let pageItems = state.exports.slice(start, start + HISTORY_PAGE_SIZE);

  table.classList.remove("hidden");
  emptyEl.classList.add("hidden");

  tbody.innerHTML = pageItems.map(function (item) {
    let statusMeta = getStatusMeta(item.status);
    let ticketLabel = item.ticket_id ? ("#" + item.ticket_id) : (item.content_label && item.content_label.indexOf("Bulk") === 0 ? "Bulk" : "-");

    return '<tr>' +
      '<td>' + escapeHtml(formatDate(item.created_at)) + '</td>' +
      '<td><strong>' + escapeHtml(ticketLabel) + '</strong></td>' +
      '<td class="content-cell">' + escapeHtml(item.content_label || "-") + '</td>' +
      '<td><span class="status-pill ' + statusMeta.className + '">' + escapeHtml(statusMeta.label) + '</span>' +
      (item.error_message ? '<div class="error-text">' + escapeHtml(item.error_message) + '</div>' : '') + '</td></tr>';
  }).join("");

  // Pagination
  if (totalPages > 1) {
    paginationEl.classList.remove("hidden");
    paginationEl.innerHTML =
      '<button id="histPrev"' + (state.historyPage <= 1 ? ' disabled' : '') + '>&larr; Prev</button>' +
      '<span>Page ' + state.historyPage + ' of ' + totalPages + '</span>' +
      '<button id="histNext"' + (state.historyPage >= totalPages ? ' disabled' : '') + '>Next &rarr;</button>';

    document.getElementById("histPrev").addEventListener("click", function () {
      if (state.historyPage > 1) { state.historyPage--; renderHistoryTab(); }
    });
    document.getElementById("histNext").addEventListener("click", function () {
      if (state.historyPage < totalPages) { state.historyPage++; renderHistoryTab(); }
    });
  } else {
    paginationEl.classList.add("hidden");
  }
}

// ── Search & Bulk Export ───────────────────────────────────────────────────────

async function loadTemplates(options) {
  let silent = Boolean(options && options.silent);

  if (state.templatesLoadInFlight) {
    state.templatesLoadQueued = true;
    state.templatesQueuedSilent = state.templatesQueuedSilent && silent;
    return;
  }

  state.templatesLoadInFlight = true;
  let nextSilent = silent;

  try {
    do {
      state.templatesLoadQueued = false;
      state.templatesQueuedSilent = true;
      await performTemplatesLoad({ silent: nextSilent });
      nextSilent = state.templatesQueuedSilent;
    } while (state.templatesLoadQueued);
  } finally {
    state.templatesLoadInFlight = false;
  }
}

async function performTemplatesLoad(options) {
  let silent = Boolean(options && options.silent);
  let requestId = ++state.templatesRequestId;

  try {
    let response = await invokeWithTimeoutRetryingOnce("listTemplates", {});

    if (requestId !== state.templatesRequestId) return;

    let payload = parseInvokeResponse(response);
    if (payload && payload.success) {
      state.templates = Array.isArray(payload.templates) ? payload.templates : [];
      if (
        state.currentEditorTemplate &&
        state.currentEditorTemplate.id &&
        !state.templates.some(function (template) { return template.id === state.currentEditorTemplate.id; })
      ) {
        state.currentEditorTemplate = getDefaultTemplate();
      }
      renderBulkTemplateSelector();
      renderTemplateEditor();
    }
  } catch (error) {
    if (requestId !== state.templatesRequestId) return;
    console.error("Failed to load templates:", error);
    if (!silent) notify("error", resolveErrorMessage(error, "Unable to load templates."));
  }
}

async function loadFieldDefinitions() {
  try {
    let response = await invokeWithTimeoutRetryingOnce("getTicketFieldDefinitions", {});
    let payload = parseInvokeResponse(response);
    if (payload && payload.success) {
      state.fieldDefinitions = Array.isArray(payload.fields) ? payload.fields : [];
      state.customFields = state.fieldDefinitions.filter(function (field) {
        return !field.default && field.name && field.name.indexOf("cf_") === 0;
      });
    }
  } catch (error) {
    console.error("Failed to load ticket field definitions:", error);
  } finally {
    ensureEditorTemplateState();
    renderTemplateEditor();
  }
}

function renderBulkTemplateSelector() {
  let select = document.getElementById("bulkTemplateSelect");
  let currentValue = select.value || "__default__";
  let options = ['<option value="__default__">Default</option>'];
  state.templates.forEach(function (t) {
    options.push('<option value="' + escapeHtml(t.id) + '">' + escapeHtml(t.name) + '</option>');
  });
  select.innerHTML = options.join("");
  let exists = state.templates.some(function (template) {
    return template.id === currentValue;
  });
  select.value = exists ? currentValue : "__default__";
}

function getSearchFilters() {
  return {
    ticket_id: document.getElementById("filterTicketId").value.trim(),
    subject: document.getElementById("filterSubject").value.trim(),
    status: document.getElementById("filterStatus").value,
    priority: document.getElementById("filterPriority").value,
    created_after: document.getElementById("filterCreatedAfter").value,
    created_before: document.getElementById("filterCreatedBefore").value,
  };
}

function validateSearchFilters(filters) {
  if (!filters || !filters.created_after || !filters.created_before) {
    return "";
  }

  let startTime = new Date(filters.created_after + "T00:00:00").getTime();
  let endTime = new Date(filters.created_before + "T00:00:00").getTime();

  if (Number.isFinite(startTime) && Number.isFinite(endTime) && startTime > endTime) {
    return "'Created After' must be on or before 'Created Before'.";
  }

  return "";
}

function clearFilters() {
  document.getElementById("filterTicketId").value = "";
  document.getElementById("filterSubject").value = "";
  document.getElementById("filterStatus").value = "";
  document.getElementById("filterPriority").value = "";
  document.getElementById("filterCreatedAfter").value = "";
  document.getElementById("filterCreatedBefore").value = "";
  state.searchResults = [];
  state.searchTotal = 0;
  state.searchPage = 1;
  state.selectedTicketIds.clear();
  state.searchPerformed = false;
  renderSearchResults();
  updateSelectionCount();
}

async function searchTickets() {
  let filters = getSearchFilters();
  let validationError = validateSearchFilters(filters);
  if (validationError) {
    notify("error", validationError);
    return;
  }

  state.searchLoading = true;
  state.searchPerformed = true;
  renderSearchResults();

  try {
    let response = await invokeWithTimeout(
      "searchTickets",
      {
        filters: filters,
        page: state.searchPage,
      },
      SEARCH_INVOKE_TIMEOUT_MS
    );

    let payload = parseInvokeResponse(response);
    if (!payload || payload.success === false) {
      throw new Error(resolveInvokeError(payload) || "Search failed.");
    }

    state.searchResults = Array.isArray(payload.tickets) ? payload.tickets : [];
    state.searchTotal = payload.total || state.searchResults.length;
  } catch (error) {
    console.error("Search failed:", error);
    notify("error", resolveErrorMessage(error, "Failed to search tickets."));
    state.searchResults = [];
    state.searchTotal = 0;
  } finally {
    state.searchLoading = false;
    renderSearchResults();
  }
}

function renderSearchResults() {
  let loadingEl = document.getElementById("searchLoading");
  let table = document.getElementById("searchTable");
  let emptyEl = document.getElementById("searchEmpty");
  let tbody = document.getElementById("searchTableBody");
  let paginationEl = document.getElementById("searchPagination");

  if (state.searchLoading) {
    loadingEl.classList.remove("hidden");
    table.classList.add("hidden");
    emptyEl.classList.add("hidden");
    paginationEl.classList.add("hidden");
    updateSelectionCount();
    return;
  }

  loadingEl.classList.add("hidden");

  if (!state.searchResults.length) {
    table.classList.add("hidden");
    emptyEl.classList.remove("hidden");
    emptyEl.textContent = state.searchPerformed
      ? "No tickets found matching your filters."
      : "Search for tickets using the filters above to get started.";
    paginationEl.classList.add("hidden");
    updateSelectionCount();
    return;
  }

  table.classList.remove("hidden");
  emptyEl.classList.add("hidden");

  tbody.innerHTML = state.searchResults.map(function (ticket) {
    let isSelected = state.selectedTicketIds.has(ticket.id);
    let isPrinting = state.individualPrintingIds.has(ticket.id);
    let selectionLimitReached = isBulkSelectionLimitReached();
    let statusBadge = getStatusBadge(ticket.status_label || resolveStatusLabelLocal(ticket.status));
    let priorityBadge = getPriorityBadge(ticket.priority_label || resolvePriorityLabelLocal(ticket.priority));

    return '<tr>' +
      '<td><input type="checkbox" data-ticket-id="' + ticket.id + '"' + (isSelected ? ' checked' : '') + (!isSelected && selectionLimitReached ? ' disabled' : '') + '></td>' +
      '<td><strong>#' + escapeHtml(String(ticket.id)) + '</strong></td>' +
      '<td class="content-cell">' + escapeHtml(ticket.subject || "-") + '</td>' +
      '<td>' + statusBadge + '</td>' +
      '<td>' + priorityBadge + '</td>' +
      '<td>' + escapeHtml(formatDate(ticket.created_at)) + '</td>' +
      '<td><button class="btn btn-secondary" data-print-id="' + ticket.id + '"' + (isPrinting ? ' disabled' : '') + '>' +
      (isPrinting ? '<span class="spinner"></span>Printing' : 'Print') + '</button></td>' +
      '</tr>';
  }).join("");

  // Checkbox listeners
  tbody.querySelectorAll('[data-ticket-id]').forEach(function (cb) {
    cb.addEventListener("change", function () {
      let tid = Number(cb.getAttribute("data-ticket-id"));
      cb.checked = applyTicketSelection(tid, cb.checked);
      updateSelectionCount();
      renderSearchResults();
    });
  });

  // Print listeners
  tbody.querySelectorAll('[data-print-id]').forEach(function (btn) {
    btn.addEventListener("click", function () {
      printIndividualTicket(Number(btn.getAttribute("data-print-id")));
    });
  });

  // Header checkbox
  let allSelected = state.searchResults.every(function (t) { return state.selectedTicketIds.has(t.id); });
  let selectAllCb = document.getElementById("selectAllCb");
  selectAllCb.checked = allSelected;
  selectAllCb.disabled = !state.searchResults.length || (isBulkSelectionLimitReached() && !allSelected);

  // Pagination
  let totalPages = Math.ceil(state.searchTotal / SEARCH_PAGE_SIZE);
  if (totalPages > 1) {
    paginationEl.classList.remove("hidden");
    paginationEl.innerHTML =
      '<button id="searchPrev"' + (state.searchPage <= 1 ? ' disabled' : '') + '>&larr; Prev</button>' +
      '<span>Page ' + state.searchPage + ' of ' + totalPages + ' (' + state.searchTotal + ' results)</span>' +
      '<button id="searchNext"' + (state.searchPage >= totalPages ? ' disabled' : '') + '>Next &rarr;</button>';

    document.getElementById("searchPrev").addEventListener("click", function () {
      if (state.searchPage > 1) { state.searchPage--; searchTickets(); }
    });
    document.getElementById("searchNext").addEventListener("click", function () {
      if (state.searchPage < totalPages) { state.searchPage++; searchTickets(); }
    });
  } else {
    paginationEl.classList.add("hidden");
  }

  updateSelectionCount();
}

function selectAll() {
  let remainingSlots = getRemainingBulkSelectionSlots();
  let unselectedTickets = state.searchResults.filter(function (t) {
    return !state.selectedTicketIds.has(t.id);
  });

  if (!remainingSlots) {
    notifyBulkSelectionLimitReached();
    renderSearchResults();
    return;
  }

  unselectedTickets.slice(0, remainingSlots).forEach(function (t) {
    state.selectedTicketIds.add(t.id);
  });

  if (unselectedTickets.length > remainingSlots) {
    notifyBulkSelectionLimitReached();
  }

  renderSearchResults();
}

function deselectAll() {
  state.selectedTicketIds.clear();
  renderSearchResults();
}

function updateSelectionCount() {
  let count = state.selectedTicketIds.size;
  let limit = getBulkTicketLimit();
  document.getElementById("selectionCount").textContent = count + " selected (max " + limit + ")";
  document.getElementById("btnSelectAll").disabled = state.searchLoading || !state.searchResults.length || count >= limit;
  document.getElementById("btnDeselectAll").disabled = state.searchLoading || count === 0;
  document.getElementById("btnBulkExport").disabled = count === 0 || state.bulkExporting;
  updateBulkExportButtonLabel();
}

function updateBulkExportButtonLabel() {
  let button = document.getElementById("btnBulkExport");
  if (state.bulkExporting) {
    return;
  }

  let exportFormat = document.getElementById("bulkFormatSelect").value || "pdf";
  button.textContent = exportFormat === "zip" ? "Export Selected as ZIP" : "Print Selected as PDF";
}

async function printIndividualTicket(ticketId) {
  if (state.individualPrintingIds.has(ticketId)) return;
  state.individualPrintingIds.add(ticketId);
  renderSearchResults();

  try {
    let templateId = document.getElementById("bulkTemplateSelect").value;
    let args = { ticket_id: ticketId };
    if (templateId && templateId !== "__default__") {
      args.template_id = templateId;
    }

    let response = await invokeWithTimeout(
      "createTicketPdfExport",
      args,
      EXPORT_INVOKE_TIMEOUT_MS
    );
    let payload = parseInvokeResponse(response);

    if (!payload || !payload.success) {
      throw new Error(resolveInvokeError(payload) || "Failed to print ticket.");
    }

    if (payload.base64_data) {
      triggerDownload(payload.base64_data, payload.file_name || ("ticket-" + ticketId + ".pdf"), "application/pdf");
      notify("success", "Ticket #" + ticketId + " PDF downloaded.");
    } else {
      notify("success", "Ticket #" + ticketId + " PDF created. Check print history.");
    }
  } catch (error) {
    console.error("Individual print failed:", error);
    notify("error", resolveErrorMessage(error, "Failed to print ticket #" + ticketId + "."));
  } finally {
    state.individualPrintingIds.delete(ticketId);
    renderSearchResults();
  }
}

async function bulkExportSelected() {
  let ticketIds = Array.from(state.selectedTicketIds);
  if (!ticketIds.length) return;

  if (ticketIds.length > getBulkTicketLimit()) {
    notify("error", "Maximum " + getBulkTicketLimit() + " tickets per bulk print. Please deselect some tickets.");
    return;
  }

  state.bulkExporting = true;
  let btn = document.getElementById("btnBulkExport");
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span>Printing ' + ticketIds.length + ' ticket' + (ticketIds.length > 1 ? 's' : '') + '...';

  try {
    let templateId = document.getElementById("bulkTemplateSelect").value;
    let exportFormat = document.getElementById("bulkFormatSelect").value || "pdf";
    if (exportFormat === "zip") {
      await bulkExportSelectedAsZip(ticketIds, templateId, btn);
      return;
    }
    if (exportFormat === "pdf") {
      await bulkExportSelectedAsMergedPdf(ticketIds, templateId, btn);
      return;
    }

    let args = {
      ticket_ids: ticketIds,
      export_format: exportFormat,
    };
    if (templateId && templateId !== "__default__") {
      args.template_id = templateId;
    }

    console.info("Bulk export request started:", buildBulkExportDebugContext(args));

    let response = await invokeWithTimeout(
      "createBulkTicketPdfExport",
      args,
      EXPORT_INVOKE_TIMEOUT_MS
    );
    let payload = parseInvokeResponse(response);

    if (!payload || !payload.success) {
      throw new Error(resolveInvokeError(payload) || "Bulk export failed.");
    }

    if (payload.base64_data) {
      triggerDownload(
        payload.base64_data,
        payload.file_name || (exportFormat === "zip" ? "bulk-export.zip" : "bulk-export.pdf"),
        payload.mime_type || (exportFormat === "zip" ? "application/zip" : "application/pdf")
      );
    }

    console.info("Bulk export request completed:", {
      request: buildBulkExportDebugContext(args),
      response: {
        success: payload.success,
        file_name: payload.file_name,
        mime_type: payload.mime_type,
        export_id: payload.export && payload.export.id,
      },
    });

    notify("success", (exportFormat === "zip" ? "Bulk ZIP export" : "Bulk PDF print") + " with " + ticketIds.length + " tickets completed.");
    state.selectedTicketIds.clear();

    // Switch to history tab and refresh
    switchTab("history");
    await loadExportHistory();
  } catch (error) {
    console.error("Bulk export failed:", {
      request: buildBulkExportDebugContext({
        ticket_ids: ticketIds,
        export_format: document.getElementById("bulkFormatSelect").value || "pdf",
        template_id: document.getElementById("bulkTemplateSelect").value,
      }),
      error: buildErrorLogDetails(error),
    });
    notify("error", resolveErrorMessage(error, "Failed to bulk print tickets."));
  } finally {
    state.bulkExporting = false;
    btn.disabled = false;
    updateSelectionCount();
    renderSearchResults();
  }
}

async function bulkExportSelectedAsZip(ticketIds, templateId, btn) {
  let args = {
    ticket_ids: ticketIds.slice(),
    export_format: "zip",
  };
  if (templateId && templateId !== "__default__") {
    args.template_id = templateId;
  }

  console.info("Bulk ZIP client assembly started:", buildBulkExportDebugContext(args));

  let zipEntries = [];
  let failedCount = 0;

  for (let index = 0; index < ticketIds.length; index += 1) {
    let ticketId = ticketIds[index];
    btn.innerHTML = '<span class="spinner"></span>Preparing ZIP ' + (index + 1) + '/' + ticketIds.length + '...';

    try {
      let payload = await requestTransientTicketPdfExport(ticketId, templateId);
      zipEntries.push({
        name: payload.file_name || ("ticket-" + ticketId + ".pdf"),
        data: base64ToBytes(payload.base64_data),
      });
    } catch (error) {
      failedCount += 1;
      let detail = resolveErrorMessage(error, "Failed to export ticket #" + ticketId + ".");
      console.error("Ticket ZIP member export failed:", {
        ticketId: ticketId,
        error: buildErrorLogDetails(error),
      });
      zipEntries.push({
        name: buildZipErrorEntryName(ticketId),
        data: encodeZipText("Ticket #" + ticketId + " failed to export.\n" + detail),
      });
    }

    if (index + 1 < ticketIds.length) {
      await sleep(ZIP_MEMBER_EXPORT_GAP_MS);
    }
  }

  if (!zipEntries.length) {
    throw new Error("No files were generated for the ZIP export.");
  }

  let zipFileName = buildBulkZipFileName(ticketIds, Date.now());
  let zipBlob = buildZipBlobFromEntries(zipEntries, Date.now());
  triggerBlobDownload(zipBlob, zipFileName);
  let historySaved = await tryRecordBulkZipExportHistory(ticketIds, zipFileName, failedCount, btn);

  console.info("Bulk ZIP client assembly completed:", {
    request: buildBulkExportDebugContext(args),
    entryCount: zipEntries.length,
    failedEntries: failedCount,
    zipSizeBytes: zipBlob.size,
    historySaved: historySaved,
  });

  state.selectedTicketIds.clear();
  renderSearchResults();

  if (historySaved) {
    switchTab("history");
    await loadExportHistory();
  } else {
    notify("error", "ZIP downloaded, but it could not be added to print history.");
  }

  if (!failedCount) {
    notify("success", "Bulk ZIP export with " + ticketIds.length + " tickets completed.");
    return;
  }

  if (failedCount < ticketIds.length) {
    notify("success", "Bulk ZIP downloaded with " + failedCount + " ticket errors. See TXT files inside the ZIP.");
    return;
  }

  notify("error", "ZIP downloaded, but all ticket exports failed. See TXT files inside the ZIP.");
}

async function bulkExportSelectedAsMergedPdf(ticketIds, templateId, btn) {
  let args = {
    ticket_ids: ticketIds.slice(),
    export_format: "pdf",
  };
  if (templateId && templateId !== "__default__") {
    args.template_id = templateId;
  }

  console.info("Bulk merged PDF client assembly started:", buildBulkExportDebugContext(args));

  let pageStreams = [];
  let failedCount = 0;
  let template = resolveClientTemplateForExport(templateId);
  let transientTemplate = Object.assign({}, template, { show_page_numbers: false });

  for (let index = 0; index < ticketIds.length; index += 1) {
    let ticketId = ticketIds[index];
    btn.innerHTML = '<span class="spinner"></span>Preparing PDF ' + (index + 1) + '/' + ticketIds.length + '...';

    try {
      let payload = await requestTransientTicketPdfExport(ticketId, templateId, {
        template: transientTemplate,
      });
      let streams = extractGeneratedPdfPageStreams(base64ToBytes(payload.base64_data));
      if (!streams.length) {
        throw new Error("No PDF pages were returned for ticket #" + ticketId + ".");
      }
      pageStreams.push.apply(pageStreams, streams);
    } catch (error) {
      failedCount += 1;
      let detail = resolveErrorMessage(error, "Failed to export ticket #" + ticketId + ".");
      console.error("Ticket merged PDF member export failed:", {
        ticketId: ticketId,
        error: buildErrorLogDetails(error),
      });
      pageStreams.push(buildPdfErrorPageStream(ticketId, detail));
    }

    if (index + 1 < ticketIds.length) {
      await sleep(ZIP_MEMBER_EXPORT_GAP_MS);
    }
  }

  if (!pageStreams.length) {
    throw new Error("No pages were generated for the merged PDF export.");
  }

  let pdfFileName = buildBulkPdfFileName(ticketIds, Date.now());
  let pdfBlob = buildMergedPdfBlobFromPageStreams(pageStreams, template);
  triggerBlobDownload(pdfBlob, pdfFileName);
  let historySaved = await tryRecordClientBulkExportHistory(ticketIds, pdfFileName, failedCount, "pdf", btn);

  console.info("Bulk merged PDF client assembly completed:", {
    request: buildBulkExportDebugContext(args),
    pageCount: pageStreams.length,
    failedEntries: failedCount,
    pdfSizeBytes: pdfBlob.size,
    historySaved: historySaved,
  });

  state.selectedTicketIds.clear();
  renderSearchResults();

  if (historySaved) {
    switchTab("history");
    await loadExportHistory();
  } else {
    notify("error", "PDF downloaded, but it could not be added to print history.");
  }

  if (!failedCount) {
    notify("success", "Bulk PDF export with " + ticketIds.length + " tickets completed.");
    return;
  }

  if (failedCount < ticketIds.length) {
    notify("success", "Bulk PDF downloaded with " + failedCount + " ticket errors included in the PDF.");
    return;
  }

  notify("error", "PDF downloaded, but all ticket exports failed. See error pages in the PDF.");
}

async function tryRecordBulkZipExportHistory(ticketIds, fileName, failedCount, btn) {
  try {
    btn.innerHTML = '<span class="spinner"></span>Saving print history...';
    let response = await invokeWithTimeout("recordBulkZipExportHistory", {
      ticket_ids: ticketIds.slice(),
      file_name: fileName,
      failed_count: failedCount,
    });
    let payload = parseInvokeResponse(response);

    if (!payload || !payload.success) {
      throw new Error(resolveInvokeError(payload) || "Failed to record ZIP export history.");
    }

    return true;
  } catch (error) {
    console.error("Failed to record ZIP export history:", {
      request: {
        ticket_ids: ticketIds,
        file_name: fileName,
        failed_count: failedCount,
      },
      error: buildErrorLogDetails(error),
    });
    return false;
  }
}

async function tryRecordClientBulkExportHistory(ticketIds, fileName, failedCount, exportFormat, btn) {
  try {
    btn.innerHTML = '<span class="spinner"></span>Saving print history...';
    let response = await invokeWithTimeout("recordClientBulkExportHistory", {
      ticket_ids: ticketIds.slice(),
      file_name: fileName,
      failed_count: failedCount,
      export_format: exportFormat,
    });
    let payload = parseInvokeResponse(response);

    if (!payload || !payload.success) {
      throw new Error(resolveInvokeError(payload) || "Failed to record export history.");
    }

    return true;
  } catch (error) {
    console.error("Failed to record client bulk export history:", {
      request: {
        ticket_ids: ticketIds,
        file_name: fileName,
        failed_count: failedCount,
        export_format: exportFormat,
      },
      error: buildErrorLogDetails(error),
    });
    return false;
  }
}

async function requestTransientTicketPdfExport(ticketId, templateId, options) {
  let args = {
    ticket_id: ticketId,
    skip_history: true,
    persist_export: false,
  };
  if (options && options.template && typeof options.template === "object") {
    args.template = options.template;
  } else if (templateId && templateId !== "__default__") {
    args.template_id = templateId;
  }

  for (let attempt = 1; attempt <= ZIP_MEMBER_EXPORT_MAX_ATTEMPTS; attempt += 1) {
    try {
      let response = await invokeWithTimeout(
        "createTicketPdfExport",
        args,
        EXPORT_INVOKE_TIMEOUT_MS
      );
      let payload = parseInvokeResponse(response);

      if (!payload || !payload.success) {
        throw buildTicketExportPayloadError(payload, "Failed to export ticket #" + ticketId + ".");
      }
      if (!payload.base64_data) {
        throw new Error("No PDF data was returned for ticket #" + ticketId + ".");
      }

      return payload;
    } catch (error) {
      let canRetry = attempt < ZIP_MEMBER_EXPORT_MAX_ATTEMPTS && isRetriableTicketExportError(error);
      if (!canRetry) {
        throw error;
      }

      let delayMs = ZIP_MEMBER_EXPORT_RETRY_DELAY_MS * attempt;
      console.warn("Retrying transient ticket PDF export failure:", {
        ticketId: ticketId,
        attempt: attempt,
        nextAttempt: attempt + 1,
        delayMs: delayMs,
        error: buildErrorLogDetails(error),
      });
      await sleep(delayMs);
    }
  }
}

// ── Template Manager ───────────────────────────────────────────────────────────

function getDefaultTemplate() {
  return {
    id: null,
    name: "Default",
    visible_header_fields: ["subject", "ticket_id"],
    visible_detail_fields: ["status", "priority", "type", "tags", "requester", "agent", "created_at", "updated_at"],
    visible_custom_fields: [],
    custom_fields_mode: "all",
    include_description: true,
    include_replies: true,
    include_public_notes: true,
    include_private_notes: true,
    view_mode: "agent",
    section_order: DEFAULT_SECTION_ORDER.slice(),
    date_format: "DD MMM YYYY HH:mm",
    show_page_numbers: true,
    page_number_format: "page_of_total",
  };
}

function ensureEditorTemplateState() {
  if (!state.currentEditorTemplate) {
    state.currentEditorTemplate = getDefaultTemplate();
  }
  state.editorSectionOrder = normalizeEditorSectionOrder(state.currentEditorTemplate.section_order);
}

function renderTemplateEditor() {
  ensureEditorTemplateState();
  renderEditorTemplateSelector();
  renderEditorCustomFields();
  renderEditorSectionOrder();
  applyEditorTemplateToUI(state.currentEditorTemplate);
}

function renderEditorTemplateSelector() {
  let select = document.getElementById("editorTemplateSelect");
  if (!select) return;

  let options = ['<option value="__default__">Default</option>'];
  state.templates.forEach(function (template) {
    options.push('<option value="' + escapeHtml(template.id) + '">' + escapeHtml(template.name) + '</option>');
  });
  select.innerHTML = options.join("");
  select.value = state.currentEditorTemplate && state.currentEditorTemplate.id ? state.currentEditorTemplate.id : "__default__";

  let isDefault = !state.currentEditorTemplate || !state.currentEditorTemplate.id;
  document.getElementById("btnEditorSaveTemplate").disabled = isDefault;
  document.getElementById("btnEditorDeleteTemplate").disabled = isDefault;
}

function renderEditorCustomFields() {
  let container = document.getElementById("editorCustomFieldsList");
  if (!container) return;

  if (!state.customFields.length) {
    container.innerHTML = '<span class="muted">No custom fields found.</span>';
    return;
  }

  let allowedFields = state.currentEditorTemplate && Array.isArray(state.currentEditorTemplate.visible_custom_fields)
    ? state.currentEditorTemplate.visible_custom_fields
    : [];
  let showAll = shouldShowAllEditorCustomFields(state.currentEditorTemplate);

  container.innerHTML = state.customFields.map(function (field) {
    let checked = showAll || allowedFields.indexOf(field.name) !== -1;
    let id = "editor_cf_" + field.name;
    return '<div class="template-check-row">' +
      '<input type="checkbox" id="' + escapeHtml(id) + '" data-editor-cf="' + escapeHtml(field.name) + '"' + (checked ? ' checked' : '') + '>' +
      '<label for="' + escapeHtml(id) + '">' + escapeHtml(field.label) + '</label>' +
      '</div>';
  }).join("");
}

function renderEditorSectionOrder() {
  let list = document.getElementById("editorSectionOrderList");
  if (!list) return;

  list.innerHTML = state.editorSectionOrder.map(function (key, index) {
    return '<li class="template-order-item">' +
      '<span>' + escapeHtml(SECTION_LABELS[key] || key) + '</span>' +
      '<button class="template-order-btn" type="button" data-editor-order="up" data-editor-index="' + index + '"' + (index === 0 ? ' disabled' : '') + '>&uarr;</button>' +
      '<button class="template-order-btn" type="button" data-editor-order="down" data-editor-index="' + index + '"' + (index === state.editorSectionOrder.length - 1 ? ' disabled' : '') + '>&darr;</button>' +
      '</li>';
  }).join("");

  list.querySelectorAll("[data-editor-order]").forEach(function (button) {
    button.addEventListener("click", function () {
      moveEditorSectionOrder(Number(button.getAttribute("data-editor-index")), button.getAttribute("data-editor-order"));
    });
  });
}

function moveEditorSectionOrder(index, direction) {
  let swapIndex = direction === "up" ? index - 1 : index + 1;
  if (swapIndex < 0 || swapIndex >= state.editorSectionOrder.length) return;

  let nextOrder = state.editorSectionOrder.slice();
  let current = nextOrder[index];
  nextOrder[index] = nextOrder[swapIndex];
  nextOrder[swapIndex] = current;
  state.editorSectionOrder = nextOrder;
  renderEditorSectionOrder();
}

function applyEditorTemplateToUI(template) {
  if (!template) return;

  document.querySelectorAll('[data-group="header"]').forEach(function (checkbox) {
    checkbox.checked = (template.visible_header_fields || []).indexOf(checkbox.getAttribute("data-field")) !== -1;
  });

  document.querySelectorAll('[data-group="details"]').forEach(function (checkbox) {
    checkbox.checked = (template.visible_detail_fields || []).indexOf(checkbox.getAttribute("data-field")) !== -1;
  });

  let allowedCustomFields = Array.isArray(template.visible_custom_fields) ? template.visible_custom_fields : [];
  let showAllCustomFields = shouldShowAllEditorCustomFields(template);
  document.querySelectorAll("[data-editor-cf]").forEach(function (checkbox) {
    checkbox.checked = showAllCustomFields || allowedCustomFields.indexOf(checkbox.getAttribute("data-editor-cf")) !== -1;
  });

  document.getElementById("tpl_desc_include").checked = template.include_description !== false;
  document.getElementById("tpl_conv_replies").checked = template.include_replies !== false;
  document.getElementById("tpl_conv_public_notes").checked = template.include_public_notes !== false;
  document.getElementById("tpl_conv_private_notes").checked = template.include_private_notes !== false;
  document.getElementById("tpl_view_agent").checked = (template.view_mode || "agent") === "agent";
  document.getElementById("tpl_view_customer").checked = (template.view_mode || "agent") === "customer";

  state.editorSectionOrder = normalizeEditorSectionOrder(template.section_order);
  renderEditorSectionOrder();

  document.getElementById("editorDateFormatSelect").value = template.date_format || "DD MMM YYYY HH:mm";
  document.getElementById("editorShowPageNumbers").checked = template.show_page_numbers !== false;
  document.getElementById("editorPageNumFormatSelect").value = template.page_number_format || "page_of_total";
  syncEditorViewModeState();
}

function collectEditorConfig() {
  let headerFields = [];
  document.querySelectorAll('[data-group="header"]:checked').forEach(function (checkbox) {
    headerFields.push(checkbox.getAttribute("data-field"));
  });

  let detailFields = [];
  document.querySelectorAll('[data-group="details"]:checked').forEach(function (checkbox) {
    detailFields.push(checkbox.getAttribute("data-field"));
  });

  let customFields = [];
  let hasCustomFieldControls = false;
  document.querySelectorAll("[data-editor-cf]").forEach(function (checkbox) {
    hasCustomFieldControls = true;
    if (checkbox.checked) {
      customFields.push(checkbox.getAttribute("data-editor-cf"));
    }
  });

  let viewMode = document.getElementById("tpl_view_customer").checked ? "customer" : "agent";
  let currentTemplate = state.currentEditorTemplate || getDefaultTemplate();
  let preservedCustomFields = Array.isArray(currentTemplate.visible_custom_fields)
    ? currentTemplate.visible_custom_fields
    : [];
  let preservedCustomFieldsMode = shouldShowAllEditorCustomFields(currentTemplate) ? "all" : "selected";

  return {
    visible_header_fields: headerFields,
    visible_detail_fields: detailFields,
    visible_custom_fields: hasCustomFieldControls ? customFields : preservedCustomFields,
    custom_fields_mode: hasCustomFieldControls ? "selected" : preservedCustomFieldsMode,
    include_description: document.getElementById("tpl_desc_include").checked,
    include_replies: document.getElementById("tpl_conv_replies").checked,
    include_public_notes: document.getElementById("tpl_conv_public_notes").checked,
    include_private_notes: viewMode === "agent" ? document.getElementById("tpl_conv_private_notes").checked : false,
    view_mode: viewMode,
    section_order: normalizeEditorSectionOrder(state.editorSectionOrder),
    date_format: document.getElementById("editorDateFormatSelect").value,
    show_page_numbers: document.getElementById("editorShowPageNumbers").checked,
    page_number_format: document.getElementById("editorPageNumFormatSelect").value,
  };
}

function syncEditorViewModeState() {
  let privateNotesCheckbox = document.getElementById("tpl_conv_private_notes");
  if (document.getElementById("tpl_view_customer").checked) {
    privateNotesCheckbox.checked = false;
    privateNotesCheckbox.disabled = true;
  } else {
    privateNotesCheckbox.disabled = false;
  }
}

function normalizeEditorSectionOrder(order) {
  let normalized = [];
  let source = Array.isArray(order) ? order : DEFAULT_SECTION_ORDER;

  source.forEach(function (key) {
    if (SECTION_LABELS[key] && normalized.indexOf(key) === -1) {
      normalized.push(key);
    }
  });

  DEFAULT_SECTION_ORDER.forEach(function (key) {
    if (normalized.indexOf(key) === -1) {
      normalized.push(key);
    }
  });

  return normalized;
}

function shouldShowAllEditorCustomFields(template) {
  if (!template) return true;
  if (template.custom_fields_mode === "all") return true;
  if (template.custom_fields_mode === "selected") return false;
  if (!Array.isArray(template.visible_custom_fields)) return true;
  return !template.visible_custom_fields.length;
}

function onEditorTemplateSelect() {
  let value = document.getElementById("editorTemplateSelect").value;
  if (value === "__default__") {
    state.currentEditorTemplate = getDefaultTemplate();
  } else {
    let found = state.templates.find(function (template) {
      return template.id === value;
    });
    state.currentEditorTemplate = found || getDefaultTemplate();
  }

  applyEditorTemplateToUI(state.currentEditorTemplate);
  renderEditorTemplateSelector();
}

async function onEditorSaveTemplate() {
  if (!state.currentEditorTemplate || !state.currentEditorTemplate.id) return;

  try {
    let response = await invokeWithTimeout("saveTemplate", {
      template: Object.assign({}, state.currentEditorTemplate, collectEditorConfig()),
    });
    let payload = parseInvokeResponse(response);
    if (!payload || !payload.success) {
      throw new Error(resolveInvokeError(payload) || "Failed to save template.");
    }

    let index = state.templates.findIndex(function (template) {
      return template.id === payload.template.id;
    });
    if (index !== -1) {
      state.templates[index] = payload.template;
    }
    state.currentEditorTemplate = payload.template;
    renderBulkTemplateSelector();
    renderTemplateEditor();
    notify("success", "Template saved.");
  } catch (error) {
    console.error("Failed to save template:", error);
    notify("error", resolveErrorMessage(error, "Failed to save template."));
  }
}

function openEditorSaveAsModal() {
  document.getElementById("editorSaveAsName").value = "";
  document.getElementById("editorSaveAsModal").classList.add("visible");
  document.getElementById("editorSaveAsName").focus();
}

function closeEditorSaveAsModal() {
  document.getElementById("editorSaveAsModal").classList.remove("visible");
}

async function onEditorSaveAsConfirm() {
  let name = document.getElementById("editorSaveAsName").value.trim();
  if (!name) {
    notify("error", "Please enter a template name.");
    return;
  }

  try {
    let response = await invokeWithTimeout("saveTemplate", {
      template: Object.assign({ name: name }, collectEditorConfig()),
    });
    let payload = parseInvokeResponse(response);
    if (!payload || !payload.success) {
      throw new Error(resolveInvokeError(payload) || "Failed to save template.");
    }

    state.templates.push(payload.template);
    state.currentEditorTemplate = payload.template;
    renderBulkTemplateSelector();
    renderTemplateEditor();
    closeEditorSaveAsModal();
    notify("success", "Template created.");
  } catch (error) {
    console.error("Failed to create template:", error);
    notify("error", resolveErrorMessage(error, "Failed to save template."));
  }
}

function openEditorDeleteModal() {
  if (!state.currentEditorTemplate || !state.currentEditorTemplate.id) return;

  document.getElementById("editorDeleteConfirmText").textContent =
    'Delete "' + state.currentEditorTemplate.name + '"? This cannot be undone.';
  document.getElementById("editorDeleteModal").classList.add("visible");
  document.getElementById("btnEditorDeleteCancel").focus();
}

function closeEditorDeleteModal() {
  document.getElementById("editorDeleteModal").classList.remove("visible");
}

async function onEditorDeleteConfirm() {
  if (!state.currentEditorTemplate || !state.currentEditorTemplate.id) return;

  let confirmBtn = document.getElementById("btnEditorDeleteConfirm");
  confirmBtn.disabled = true;
  confirmBtn.textContent = "Deleting...";

  try {
    let response = await invokeWithTimeout("deleteTemplate", {
      template_id: state.currentEditorTemplate.id,
    });
    let payload = parseInvokeResponse(response);
    if (!payload || !payload.success) {
      throw new Error(resolveInvokeError(payload) || "Failed to delete template.");
    }

    state.templates = state.templates.filter(function (template) {
      return template.id !== state.currentEditorTemplate.id;
    });
    state.currentEditorTemplate = getDefaultTemplate();
    state.editorSectionOrder = state.currentEditorTemplate.section_order.slice();
    renderBulkTemplateSelector();
    renderTemplateEditor();
    closeEditorDeleteModal();
    notify("success", "Template deleted.");
  } catch (error) {
    console.error("Failed to delete template:", error);
    notify("error", resolveErrorMessage(error, "Failed to delete template."));
  } finally {
    confirmBtn.disabled = false;
    confirmBtn.textContent = "Delete";
  }
}

// ── Utilities ──────────────────────────────────────────────────────────────────

function getStatusMeta(status) {
  if (status === "ready") return { label: "Success", className: "status-ready" };
  if (status === "failed") return { label: "Failed", className: "status-failed" };
  return { label: "In Progress", className: "status-in-progress" };
}

function resolveStatusLabelLocal(statusId) {
  let map = { 2: "Open", 3: "Pending", 4: "Resolved", 5: "Closed" };
  return map[Number(statusId)] || "Status " + statusId;
}

function resolvePriorityLabelLocal(priorityId) {
  let map = { 1: "Low", 2: "Medium", 3: "High", 4: "Urgent" };
  return map[Number(priorityId)] || "Priority " + priorityId;
}

function getStatusBadge(label) {
  let cls = "badge-open";
  let lower = String(label).toLowerCase();
  if (lower === "pending") cls = "badge-pending";
  else if (lower === "resolved") cls = "badge-resolved";
  else if (lower === "closed") cls = "badge-closed";
  return '<span class="badge ' + cls + '">' + escapeHtml(label) + '</span>';
}

function getPriorityBadge(label) {
  let cls = "badge-medium";
  let lower = String(label).toLowerCase();
  if (lower === "low") cls = "badge-low";
  else if (lower === "high") cls = "badge-high";
  else if (lower === "urgent") cls = "badge-urgent";
  return '<span class="badge ' + cls + '">' + escapeHtml(label) + '</span>';
}

function triggerDownload(base64Data, fileName, mimeType) {
  let blob = new Blob([base64ToBytes(base64Data)], { type: mimeType });
  triggerBlobDownload(blob, fileName);
}

function triggerBlobDownload(blob, fileName) {
  let objectUrl = URL.createObjectURL(blob);
  let link = document.createElement("a");
  link.href = objectUrl;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(objectUrl);
}

function base64ToBytes(base64Data) {
  let binary = atob(String(base64Data || ""));
  let bytes = new Uint8Array(binary.length);

  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }

  return bytes;
}

function encodeZipText(value) {
  let text = String(value || "");
  if (typeof TextEncoder !== "undefined") {
    return new TextEncoder().encode(text);
  }

  let bytes = new Uint8Array(text.length);
  for (let i = 0; i < text.length; i++) {
    bytes[i] = text.charCodeAt(i) & 255;
  }
  return bytes;
}

function concatByteArrays(parts) {
  let totalLength = 0;
  parts.forEach(function (part) {
    totalLength += part.length;
  });

  let result = new Uint8Array(totalLength);
  let offset = 0;
  parts.forEach(function (part) {
    result.set(part, offset);
    offset += part.length;
  });
  return result;
}

function uint16ToBytes(value) {
  let normalized = Number(value) >>> 0;
  return new Uint8Array([
    normalized & 255,
    (normalized >>> 8) & 255,
  ]);
}

function uint32ToBytes(value) {
  let normalized = Number(value) >>> 0;
  return new Uint8Array([
    normalized & 255,
    (normalized >>> 8) & 255,
    (normalized >>> 16) & 255,
    (normalized >>> 24) & 255,
  ]);
}

function getZipCrc32Table() {
  if (zipCrc32Table) {
    return zipCrc32Table;
  }

  zipCrc32Table = [];
  for (let index = 0; index < 256; index += 1) {
    let value = index;
    for (let bit = 0; bit < 8; bit += 1) {
      if (value & 1) {
        value = 0xedb88320 ^ (value >>> 1);
      } else {
        value = value >>> 1;
      }
    }
    zipCrc32Table[index] = value >>> 0;
  }

  return zipCrc32Table;
}

function crc32Bytes(bytes) {
  let table = getZipCrc32Table();
  let crc = 0 ^ -1;

  for (let index = 0; index < bytes.length; index += 1) {
    crc = (crc >>> 8) ^ table[(crc ^ bytes[index]) & 255];
  }

  return (crc ^ -1) >>> 0;
}

function dateToDosTime(timestamp) {
  let date = new Date(timestamp);
  return ((date.getHours() & 31) << 11) | ((date.getMinutes() & 63) << 5) | (Math.floor(date.getSeconds() / 2) & 31);
}

function dateToDosDate(timestamp) {
  let date = new Date(timestamp);
  let year = Math.max(1980, date.getFullYear());
  return (((year - 1980) & 127) << 9) | (((date.getMonth() + 1) & 15) << 5) | (date.getDate() & 31);
}

function buildZipBlobFromEntries(entries, timestamp) {
  let localParts = [];
  let centralParts = [];
  let offset = 0;
  let dosTime = dateToDosTime(timestamp);
  let dosDate = dateToDosDate(timestamp);

  entries.forEach(function (entry) {
    let nameBytes = encodeZipText(entry && entry.name ? entry.name : "file.bin");
    let dataBytes = entry && entry.data instanceof Uint8Array
      ? entry.data
      : encodeZipText(entry && entry.data ? entry.data : "");
    let size = dataBytes.length;
    let crc = crc32Bytes(dataBytes);

    let localHeader = concatByteArrays([
      new Uint8Array([0x50, 0x4b, 0x03, 0x04]),
      uint16ToBytes(20),
      uint16ToBytes(0),
      uint16ToBytes(0),
      uint16ToBytes(dosTime),
      uint16ToBytes(dosDate),
      uint32ToBytes(crc),
      uint32ToBytes(size),
      uint32ToBytes(size),
      uint16ToBytes(nameBytes.length),
      uint16ToBytes(0),
      nameBytes,
    ]);

    let centralHeader = concatByteArrays([
      new Uint8Array([0x50, 0x4b, 0x01, 0x02]),
      uint16ToBytes(20),
      uint16ToBytes(20),
      uint16ToBytes(0),
      uint16ToBytes(0),
      uint16ToBytes(dosTime),
      uint16ToBytes(dosDate),
      uint32ToBytes(crc),
      uint32ToBytes(size),
      uint32ToBytes(size),
      uint16ToBytes(nameBytes.length),
      uint16ToBytes(0),
      uint16ToBytes(0),
      uint16ToBytes(0),
      uint16ToBytes(0),
      uint32ToBytes(0),
      uint32ToBytes(offset),
      nameBytes,
    ]);

    localParts.push(localHeader, dataBytes);
    centralParts.push(centralHeader);
    offset += localHeader.length + dataBytes.length;
  });

  let centralLength = 0;
  centralParts.forEach(function (part) {
    centralLength += part.length;
  });

  let endRecord = concatByteArrays([
    new Uint8Array([0x50, 0x4b, 0x05, 0x06]),
    uint16ToBytes(0),
    uint16ToBytes(0),
    uint16ToBytes(entries.length),
    uint16ToBytes(entries.length),
    uint32ToBytes(centralLength),
    uint32ToBytes(offset),
    uint16ToBytes(0),
  ]);

  return new Blob(localParts.concat(centralParts, [endRecord]), { type: "application/zip" });
}

function buildZipErrorEntryName(ticketId) {
  return "ticket-" + String(ticketId || 0).padStart(6, "0") + "-error.txt";
}

function buildBulkZipFileName(ticketIds, timestamp) {
  let date = new Date(timestamp);
  let stamp = [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0"),
    String(date.getHours()).padStart(2, "0"),
    String(date.getMinutes()).padStart(2, "0"),
  ].join("");
  return "bulk-" + ticketIds.length + "-tickets-" + stamp + ".zip";
}

function buildBulkPdfFileName(ticketIds, timestamp) {
  let date = new Date(timestamp);
  let stamp = [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0"),
    String(date.getHours()).padStart(2, "0"),
    String(date.getMinutes()).padStart(2, "0"),
  ].join("");
  return "bulk-" + ticketIds.length + "-tickets-" + stamp + ".pdf";
}

function resolveClientTemplateForExport(templateId) {
  if (!templateId || templateId === "__default__") {
    return getDefaultTemplate();
  }

  let found = state.templates.find(function (template) {
    return template.id === templateId;
  });
  return Object.assign({}, getDefaultTemplate(), found || {});
}

function bytesToLatin1String(bytes) {
  let chunks = [];
  for (let index = 0; index < bytes.length; index += 8192) {
    let slice = bytes.subarray(index, index + 8192);
    let text = "";
    for (let i = 0; i < slice.length; i += 1) {
      text += String.fromCharCode(slice[i]);
    }
    chunks.push(text);
  }
  return chunks.join("");
}

function latin1StringToBytes(value) {
  let text = String(value || "");
  let bytes = new Uint8Array(text.length);
  for (let index = 0; index < text.length; index += 1) {
    bytes[index] = text.charCodeAt(index) & 255;
  }
  return bytes;
}

function getLatin1ByteLength(value) {
  return String(value || "").length;
}

function escapePdfString(value) {
  return String(value || "")
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)")
    .replace(/\r/g, "\\r")
    .replace(/\n/g, "\\n");
}

function extractGeneratedPdfPageStreams(pdfBytes) {
  let pdf = bytesToLatin1String(pdfBytes);
  let streams = [];
  let regex = /stream\r?\n([\s\S]*?)\r?\nendstream/g;
  let match = regex.exec(pdf);

  while (match) {
    streams.push(match[1]);
    match = regex.exec(pdf);
  }

  return streams;
}

function buildPdfErrorPageStream(ticketId, detail) {
  let safeTitle = escapePdfString("Ticket #" + ticketId + " - Error");
  let safeDetail = escapePdfString(String(detail || "Failed to export ticket.").slice(0, 220));
  return [
    "BT",
    "/F2 16 Tf",
    "0.706 0.137 0.094 rg",
    "1 0 0 1 48.00 780.00 Tm",
    "(" + safeTitle + ") Tj",
    "ET",
    "BT",
    "/F1 11 Tf",
    "0.157 0.278 0.400 rg",
    "1 0 0 1 48.00 752.00 Tm",
    "(" + safeDetail + ") Tj",
    "ET",
  ].join("\n");
}

function formatMergedPdfPageNumber(pageNum, totalPages, format) {
  switch (format) {
    case "page_only":
      return String(pageNum);
    case "page_dash_total":
      return pageNum + " - " + totalPages;
    case "page_of_word":
      return "Page " + pageNum + " of " + totalPages;
    default:
      return pageNum + "/" + totalPages;
  }
}

function buildMergedPdfPageNumberOperation(pageNum, totalPages, format) {
  let text = formatMergedPdfPageNumber(pageNum, totalPages, format);
  let fontSize = 9;
  let approxWidth = text.length * fontSize * 0.52;
  let x = (595 - approxWidth) / 2;
  return [
    "BT",
    "/F1 9 Tf",
    "0.482 0.557 0.647 rg",
    "1 0 0 1 " + x.toFixed(2) + " 20.00 Tm",
    "(" + escapePdfString(text) + ") Tj",
    "ET",
  ].join("\n");
}

function buildMergedPdfBlobFromPageStreams(pageStreams, template) {
  let showPageNumbers = !template || template.show_page_numbers !== false;
  let pageNumFormat = (template && template.page_number_format) || "page_of_total";
  let streams = pageStreams.map(function (stream, index) {
    if (!showPageNumbers) return stream;
    return stream + "\n" + buildMergedPdfPageNumberOperation(index + 1, pageStreams.length, pageNumFormat);
  });

  let objects = [];
  objects[1] = "";
  objects[2] = "";
  objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
  objects[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>";
  objects[5] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique >>";
  objects[6] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-BoldOblique >>";
  objects[7] = "<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>";

  let pageRefs = [];
  let nextObjectId = 8;
  streams.forEach(function (stream) {
    let contentObjectId = nextObjectId;
    let pageObjectId = nextObjectId + 1;
    let length = getLatin1ByteLength(stream);
    objects[contentObjectId] = "<< /Length " + length + " >>\nstream\n" + stream + "\nendstream";
    objects[pageObjectId] =
      "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] " +
      "/Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R /F4 6 0 R /F5 7 0 R >> >> " +
      "/Contents " + contentObjectId + " 0 R >>";
    pageRefs.push(pageObjectId + " 0 R");
    nextObjectId += 2;
  });

  objects[2] = "<< /Type /Pages /Count " + streams.length + " /Kids [" + pageRefs.join(" ") + "] >>";
  objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";

  let pdf = "%PDF-1.4\n%\xFF\xFF\xFF\xFF\n";
  let offsets = [0];
  for (let objectId = 1; objectId < objects.length; objectId += 1) {
    offsets[objectId] = getLatin1ByteLength(pdf);
    pdf += objectId + " 0 obj\n" + objects[objectId] + "\nendobj\n";
  }

  let xrefOffset = getLatin1ByteLength(pdf);
  pdf += "xref\n0 " + objects.length + "\n";
  pdf += "0000000000 65535 f \n";
  for (let oid = 1; oid < objects.length; oid += 1) {
    pdf += String(offsets[oid]).padStart(10, "0") + " 00000 n \n";
  }
  pdf += "trailer\n<< /Size " + objects.length + " /Root 1 0 R >>\nstartxref\n" + xrefOffset + "\n%%EOF";

  return new Blob([latin1StringToBytes(pdf)], { type: "application/pdf" });
}

function parseInvokeResponse(result) {
  if (!result) return null;
  if (typeof result === "string") {
    try { return JSON.parse(result); } catch { return null; }
  }
  if (typeof result.response === "string") {
    try { return JSON.parse(result.response); } catch { return null; }
  }
  if (result.response && typeof result.response === "object") return result.response;
  return typeof result === "object" ? result : null;
}

function resolveInvokeError(payload) {
  if (!payload) return "";
  return payload.detail ||
    payload.message ||
    payload.description ||
    (payload.error && (payload.error.detail || payload.error.message || payload.error.description)) ||
    "";
}

function resolveErrorMessage(error, fallback) {
  if (error && error.detail) return error.detail;
  if (error && error.message) return error.message;
  if (typeof error === "string") return error;
  if (error && typeof error === "object") {
    try {
      return JSON.stringify(error);
    } catch {
      return fallback;
    }
  }
  return fallback;
}

function buildInvokeError(functionName, error) {
  const payload = parseInvokeResponse(error);
  const detail = resolveInvokeError(payload);
  const message = detail || resolveErrorMessage(error, "Request failed.");
  const invokeError = new Error(message);
  invokeError.name = "InvokeError";
  invokeError.functionName = functionName;
  invokeError.detail = detail || message;
  invokeError.status = error && error.status;
  invokeError.errorSource = error && error.errorSource;
  invokeError.payload = payload;
  invokeError.raw = error;
  return invokeError;
}

function buildErrorLogDetails(error) {
  return {
    message: resolveErrorMessage(error, "Unknown error."),
    detail: error && error.detail,
    status: error && error.status,
    errorSource: error && error.errorSource,
    functionName: error && error.functionName,
    payload: error && error.payload,
    raw: error && error.raw ? error.raw : error,
    stack: error && error.stack,
  };
}

function buildBulkExportDebugContext(args) {
  let ticketIds = args && Array.isArray(args.ticket_ids) ? args.ticket_ids.slice() : [];
  return {
    requestedAt: new Date().toISOString(),
    exportFormat: args && args.export_format ? args.export_format : "pdf",
    templateId: args && args.template_id ? args.template_id : "__default__",
    ticketCount: ticketIds.length,
    ticketIds: ticketIds,
    bulkTicketLimit: getBulkTicketLimit(),
    selectedTicketIds: Array.from(state.selectedTicketIds),
    historyEntriesLoaded: state.exports.length,
  };
}

function sleep(ms) {
  return new Promise(function (resolve) {
    setTimeout(resolve, Math.max(0, Number(ms) || 0));
  });
}

function buildTicketExportPayloadError(payload, fallbackMessage) {
  let message = resolveInvokeError(payload) || fallbackMessage || "Ticket export failed.";
  let error = new Error(message);
  error.name = "TicketExportPayloadError";
  error.detail = message;
  error.payload = payload;
  error.status = payload && payload.status;
  error.errorSource = payload && payload.errorSource;
  return error;
}

function isRetriableTicketExportError(error) {
  if (isTimeoutError(error)) {
    return true;
  }

  let status = Number(error && error.status);
  if (Number.isInteger(status) && status >= 500) {
    return true;
  }

  let message = resolveErrorMessage(error, "");
  if (typeof message === "string") {
    let normalized = message.toLowerCase();
    if (normalized.indexOf("status 429") !== -1 || normalized.indexOf("rate limit") !== -1) {
      return true;
    }
  }

  return false;
}

function invokeWithTimeout(name, args, timeoutMs) {
  return new Promise(function (resolve, reject) {
    let timer = setTimeout(function () {
      reject(new Error("Request timed out. Please try again."));
    }, timeoutMs || INVOKE_TIMEOUT_MS);

    client.request.invoke(name, args).then(
      function (result) {
        clearTimeout(timer);
        resolve(result);
      },
      function (error) {
        clearTimeout(timer);
        let invokeError = buildInvokeError(name, error);
        console.error("Invoke request failed:", {
          functionName: name,
          timeoutMs: timeoutMs || INVOKE_TIMEOUT_MS,
          args: args,
          parsedPayload: invokeError.payload,
          raw: error,
        });
        reject(invokeError);
      }
    );
  });
}

async function invokeWithTimeoutRetryingOnce(name, args, timeoutMs) {
  try {
    return await invokeWithTimeout(name, args, timeoutMs);
  } catch (error) {
    if (!isTimeoutError(error)) {
      throw error;
    }

    console.warn("Retrying timed out request:", name);
    return invokeWithTimeout(name, args, timeoutMs);
  }
}

function isTimeoutError(error) {
  let message = resolveErrorMessage(error, "");
  return typeof message === "string" && message.toLowerCase().indexOf("timed out") !== -1;
}

function getBulkTicketLimit() {
  return Math.max(1, Number(state.bulkTicketLimit) || 10);
}

function getRemainingBulkSelectionSlots() {
  return Math.max(0, getBulkTicketLimit() - state.selectedTicketIds.size);
}

function isBulkSelectionLimitReached() {
  return state.selectedTicketIds.size >= getBulkTicketLimit();
}

function notifyBulkSelectionLimitReached() {
  notify("error", "You can select up to " + getBulkTicketLimit() + " tickets per bulk print.");
}

function applyTicketSelection(ticketId, shouldSelect) {
  if (!shouldSelect) {
    state.selectedTicketIds.delete(ticketId);
    return false;
  }

  if (state.selectedTicketIds.has(ticketId)) {
    return true;
  }

  if (isBulkSelectionLimitReached()) {
    notifyBulkSelectionLimitReached();
    return false;
  }

  state.selectedTicketIds.add(ticketId);
  return true;
}

function notify(type, message) {
  let notifyType = type === "error" ? "danger" : type;
  client.interface.trigger("showNotify", { type: notifyType, message: message });
}

function formatDate(timestamp) {
  if (!timestamp) return "-";
  try {
    return new Date(timestamp).toLocaleDateString(undefined, {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return "-";
  }
}

function escapeHtml(text) {
  let div = document.createElement("div");
  div.textContent = text === null || text === undefined ? "" : String(text);
  return div.innerHTML;
}
