// ── Constants ──────────────────────────────────────────────────────────────────
const EXPORTS_KEY = "tpx_exports_v1";
const EXPORT_CHUNK_PREFIX = "tpxp_";
const TEMPLATES_KEY = "tpx_templates_v1";
const DEFAULT_MAX_RECENT_EXPORTS = 50;
const DEFAULT_MAX_TEMPLATES = 20;
// Keep the bulk cap within the serverless execution window for larger tickets.
const DEFAULT_MAX_BULK_TICKETS = 10;
const PAGE_SIZE = 100;
const PDF_CHUNK_SIZE = 24000;
const PAGE_WIDTH = 595;
const PAGE_HEIGHT = 842;
const PAGE_MARGIN = 48;
const CONTENT_WIDTH = PAGE_WIDTH - PAGE_MARGIN * 2;
const BULK_BATCH_SIZE = 1;
const BULK_BATCH_DELAY_MS = 1500;
const MAX_RATE_LIMIT_RETRIES = 3;
const SUBJECT_SEARCH_SCAN_PAGES = 10;
const DEFAULT_SECTION_ORDER = ["header", "details", "custom_fields", "description", "conversations"];
const EXPORT_STALE_IN_PROGRESS_MS = 5 * 60 * 1000;

// ── Field definition cache (per invocation) ────────────────────────────────────
let cachedFieldDefinitions = null;

// ── Utility helpers ────────────────────────────────────────────────────────────

function parseArgs(args) {
  if (!args) return {};
  if (typeof args.body === "string") {
    return JSON.parse(args.body);
  }
  if (args.body && typeof args.body === "object") {
    return args.body;
  }
  return args;
}

function normalizeText(value) {
  return String(value || "").trim();
}

function parsePositiveIntegerSetting(settings, key, defaultValue, maxValue) {
  const rawValue = settings && settings[key];
  if (rawValue === undefined || rawValue === null || rawValue === "") {
    return defaultValue;
  }

  const value = typeof rawValue === "number" ? rawValue : Number(String(rawValue).trim());
  if (!Number.isInteger(value) || value < 1) {
    return defaultValue;
  }

  if (Number.isInteger(maxValue) && value > maxValue) {
    return defaultValue;
  }

  return value;
}

function getAppSettingsFromArgs(args) {
  if (args && args.app_settings) {
    return args.app_settings;
  }
  return args || {};
}

function resolveAppRuntimeConfig(args) {
  const settings = getAppSettingsFromArgs(args);
  return {
    maxRecentExports: parsePositiveIntegerSetting(settings, "max_recent_exports", DEFAULT_MAX_RECENT_EXPORTS),
    maxTemplates: parsePositiveIntegerSetting(settings, "max_templates", DEFAULT_MAX_TEMPLATES),
    maxBulkTickets: parsePositiveIntegerSetting(
      settings,
      "max_bulk_tickets",
      DEFAULT_MAX_BULK_TICKETS,
      DEFAULT_MAX_BULK_TICKETS
    ),
  };
}

function requireAppSettingInteger(settings, key, maxValue) {
  const rawValue = settings && settings[key];
  if (rawValue === undefined || rawValue === null || rawValue === "") {
    throw new Error(key + " is required.");
  }

  const value = typeof rawValue === "number" ? rawValue : Number(String(rawValue).trim());
  if (!Number.isInteger(value) || value < 1) {
    throw new Error(key + " must be a positive integer.");
  }

  if (Number.isInteger(maxValue) && value > maxValue) {
    throw new Error(key + " must be less than or equal to " + maxValue + ".");
  }

  return value;
}

function validateAppSettings(args) {
  const settings = getAppSettingsFromArgs(args);
  requireAppSettingInteger(settings, "max_recent_exports");
  requireAppSettingInteger(settings, "max_templates");
  requireAppSettingInteger(settings, "max_bulk_tickets", DEFAULT_MAX_BULK_TICKETS);
}

function buildErrorMessage(error, fallback) {
  if (!error) {
    return fallback || "Unknown error.";
  }

  const parts = [];
  if (error.status) {
    parts.push(`Status ${error.status}`);
  }
  if (error.message && error.message !== "UNKNOWN ERROR") {
    parts.push(String(error.message));
  }

  const responseText = error.response || error.responseText || error.body || "";
  if (responseText) {
    try {
      const parsed = typeof responseText === "string" ? JSON.parse(responseText) : responseText;
      parts.push(
        parsed.description ||
          parsed.message ||
          (Array.isArray(parsed.errors) ? parsed.errors.join("; ") : JSON.stringify(parsed))
      );
    } catch {
      parts.push(String(responseText));
    }
  }

  if (!parts.length) {
    parts.push(fallback || "Unknown error.");
  }

  return parts.join(" - ");
}

function buildResponse(data) {
  return renderData(null, data);
}

function buildErrorResponse(message, error) {
  const detail = buildErrorMessage(error, message);
  console.error(message, {
    detail,
    status: error && error.status,
    response: error && (error.response || error.responseText || error.body || ""),
    stack: error && error.stack,
  });

  return renderData(null, {
    success: false,
    message,
    detail,
  });
}

function sleep(ms) {
  const waitMs = Math.max(0, Number(ms) || 0);
  if (!waitMs) {
    return Promise.resolve();
  }

  return new Promise(function (resolve) {
    try {
      const buffer = new SharedArrayBuffer(4);
      const view = new Int32Array(buffer);
      Atomics.wait(view, 0, 0, waitMs);
    } catch {
      const end = Date.now() + waitMs;
      while (Date.now() < end) {
        // Fallback for runtimes without SharedArrayBuffer/Atomics.wait.
      }
    }
    resolve();
  });
}

// ── Database helpers ───────────────────────────────────────────────────────────

async function readDbJson(key, fallbackValue) {
  try {
    return await $db.get(key);
  } catch (error) {
    if (error && error.status === 404) {
      return fallbackValue;
    }
    throw error;
  }
}

async function deleteDbKey(key) {
  try {
    await $db.delete(key);
  } catch (error) {
    if (!error || error.status !== 404) {
      throw error;
    }
  }
}

// ── Export index helpers ───────────────────────────────────────────────────────

async function readExportIndex() {
  const stored = await readDbJson(EXPORTS_KEY, { items: [] });
  return Array.isArray(stored && stored.items) ? stored.items : [];
}

async function writeExportIndex(items) {
  await $db.set(EXPORTS_KEY, { items });
}

function buildExportId() {
  return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
}

function buildChunkKey(exportId, index) {
  return `${EXPORT_CHUNK_PREFIX}${String(exportId || "").slice(-12)}_${index}`;
}

async function deleteExportPayload(record) {
  const count = Number(record && record.chunk_count);
  if (!Number.isInteger(count) || count < 1) {
    return;
  }

  for (let index = 0; index < count; index += 1) {
    await deleteDbKey(buildChunkKey(record.id, index));
  }
}

async function pruneExportIndex(items, config) {
  const maxRecentExports = (config && config.maxRecentExports) || DEFAULT_MAX_RECENT_EXPORTS;
  const sorted = [...items].sort(function (left, right) {
    return Number(right.created_at || 0) - Number(left.created_at || 0);
  });
  const kept = sorted.slice(0, maxRecentExports);
  const removed = sorted.slice(maxRecentExports);

  for (const record of removed) {
    await deleteExportPayload(record);
  }

  await writeExportIndex(kept);
  return kept;
}

async function upsertExportRecord(record, config) {
  const items = await readExportIndex();
  const nextItems = [record, ...items.filter(function (item) { return item.id !== record.id; })];
  return pruneExportIndex(nextItems, config);
}

async function markStaleInProgressExports(items) {
  const now = Date.now();
  let changed = false;
  const nextItems = items.map(function (item) {
    let createdAt = Number(item && item.created_at) || 0;
    if (item && item.status === "in_progress" && createdAt && now - createdAt > EXPORT_STALE_IN_PROGRESS_MS) {
      changed = true;
      return Object.assign({}, item, {
        status: "failed",
        error_message: item.error_message || "Export timed out before it could finish. Please try again or use ZIP for large batches.",
      });
    }
    return item;
  });

  if (changed) {
    await writeExportIndex(nextItems);
  }

  return nextItems;
}

// ── PDF chunk storage ──────────────────────────────────────────────────────────

async function storePdfChunks(exportId, pdfBase64) {
  let chunkCount = 0;

  try {
    for (let start = 0; start < pdfBase64.length; start += PDF_CHUNK_SIZE) {
      let chunk = pdfBase64.slice(start, start + PDF_CHUNK_SIZE);
      await $db.set(buildChunkKey(exportId, chunkCount), { data: chunk });
      chunkCount += 1;
    }
  } catch (error) {
    for (let index = 0; index < chunkCount; index += 1) {
      await deleteDbKey(buildChunkKey(exportId, index));
    }
    throw error;
  }

  return chunkCount;
}

async function readPdfChunks(record) {
  const count = Number(record && record.chunk_count);
  if (!Number.isInteger(count) || count < 1) {
    return "";
  }

  const parts = [];
  for (let index = 0; index < count; index += 1) {
    const chunk = await readDbJson(buildChunkKey(record.id, index), { data: "" });
    parts.push(chunk && chunk.data ? String(chunk.data) : "");
  }
  return parts.join("");
}

// ── Template DB helpers ────────────────────────────────────────────────────────

async function readTemplateIndex() {
  const stored = await readDbJson(TEMPLATES_KEY, { items: [] });
  return Array.isArray(stored && stored.items) ? stored.items : [];
}

async function writeTemplateIndex(templates) {
  await $db.set(TEMPLATES_KEY, { items: templates });
}

function getDefaultTemplate() {
  return {
    id: null,
    name: "Default",
    created_at: null,
    updated_at: null,
    visible_header_fields: ["subject", "ticket_id"],
    visible_detail_fields: ["status", "priority", "type", "tags", "requester", "agent", "created_at", "updated_at"],
    visible_custom_fields: [],
    custom_fields_mode: "all",
    include_description: true,
    include_replies: true,
    include_public_notes: true,
    include_private_notes: true,
    view_mode: "agent",
    section_order: DEFAULT_SECTION_ORDER.slice(),
    date_format: "DD MMM YYYY HH:mm",
    show_page_numbers: true,
    page_number_format: "page_of_total",
  };
}

// ── API helpers ────────────────────────────────────────────────────────────────

async function invokeRequestTemplate(name, context) {
  const response = await $request.invokeTemplate(name, {
    context: context || {},
  });

  try {
    return JSON.parse(response.response || "null");
  } catch {
    return response.response;
  }
}

async function rateLimitedInvoke(name, context) {
  for (let attempt = 0; attempt <= MAX_RATE_LIMIT_RETRIES; attempt += 1) {
    try {
      return await invokeRequestTemplate(name, context);
    } catch (error) {
      if (error && error.status === 429 && attempt < MAX_RATE_LIMIT_RETRIES) {
        const retryAfterHeader = error.headers && (
          error.headers["retry-after"] ||
          error.headers["Retry-After"] ||
          error.headers.retry_after
        );
        const retryAfterSeconds = Number(retryAfterHeader);
        const waitMs = Math.min((Number.isFinite(retryAfterSeconds) ? retryAfterSeconds : 30) * 1000, 60000);
        await sleep(waitMs);
        continue;
      }
      throw error;
    }
  }
}

async function fetchPaginated(templateName, context) {
  const items = [];

  for (let page = 1; page < 100; page += 1) {
    const pageItems = await rateLimitedInvoke(templateName, {
      ...(context || {}),
      page,
      per_page: PAGE_SIZE,
    });

    if (!Array.isArray(pageItems) || !pageItems.length) {
      break;
    }

    items.push(...pageItems);

    if (pageItems.length < PAGE_SIZE) {
      break;
    }
  }

  return items;
}

async function mapInBatches(items, batchSize, mapper) {
  const results = [];

  for (let index = 0; index < items.length; index += batchSize) {
    const slice = items.slice(index, index + batchSize);
    const mapped = await Promise.all(slice.map(mapper));
    results.push(...mapped);
  }

  return results;
}

// ── Static label resolvers ─────────────────────────────────────────────────────

function resolveStatusLabel(statusId) {
  const map = { 2: "Open", 3: "Pending", 4: "Resolved", 5: "Closed", 6: "Waiting on Customer", 7: "Waiting on Third Party" };
  return map[Number(statusId)] || ("Status " + statusId);
}

function resolvePriorityLabel(priorityId) {
  const map = { 1: "Low", 2: "Medium", 3: "High", 4: "Urgent" };
  return map[Number(priorityId)] || ("Priority " + priorityId);
}

function resolveSourceLabel(sourceId) {
  const map = { 1: "Email", 2: "Portal", 3: "Phone", 7: "Chat", 9: "Feedback Widget", 10: "Outbound Email" };
  return map[Number(sourceId)] || ("Source " + sourceId);
}

// ── Date formatting ────────────────────────────────────────────────────────────

const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const MONTH_SHORT = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function formatTicketDate(isoString, dateFormat) {
  if (!isoString) return "-";
  let d;
  try {
    d = new Date(isoString);
    if (isNaN(d.getTime())) return String(isoString);
  } catch {
    return String(isoString);
  }

  let yyyy = d.getUTCFullYear();
  let MM = String(d.getUTCMonth() + 1).padStart(2, "0");
  let dd = String(d.getUTCDate()).padStart(2, "0");
  let HH = String(d.getUTCHours()).padStart(2, "0");
  let mm = String(d.getUTCMinutes()).padStart(2, "0");
  let monthShort = MONTH_SHORT[d.getUTCMonth()];
  let monthFull = MONTH_NAMES[d.getUTCMonth()];
  let h12 = d.getUTCHours() % 12 || 12;
  let hh = String(h12).padStart(2, "0");
  let ampm = d.getUTCHours() >= 12 ? "PM" : "AM";

  switch (dateFormat) {
    case "YYYY-MM-DD HH:mm":
      return yyyy + "-" + MM + "-" + dd + " " + HH + ":" + mm;
    case "DD/MM/YYYY HH:mm":
      return dd + "/" + MM + "/" + yyyy + " " + HH + ":" + mm;
    case "MM/DD/YYYY hh:mm A":
      return MM + "/" + dd + "/" + yyyy + " " + hh + ":" + mm + " " + ampm;
    case "DD MMM YYYY HH:mm":
      return dd + " " + monthShort + " " + yyyy + " " + HH + ":" + mm;
    case "MMM DD, YYYY hh:mm A":
      return monthShort + " " + dd + ", " + yyyy + " " + hh + ":" + mm + " " + ampm;
    case "YYYY-MM-DD":
      return yyyy + "-" + MM + "-" + dd;
    case "DD MMM YYYY":
      return dd + " " + monthShort + " " + yyyy;
    case "DD-MM-YYYY HH:mm":
      return dd + "-" + MM + "-" + yyyy + " " + HH + ":" + mm;
    case "MMMM DD, YYYY":
      return monthFull + " " + dd + ", " + yyyy;
    case "DD MMMM YYYY":
      return dd + " " + monthFull + " " + yyyy;
    default:
      return dd + " " + monthShort + " " + yyyy + " " + HH + ":" + mm;
  }
}

function formatDateTime(timestamp) {
  let date = new Date(Number(timestamp || Date.now()));
  let year = date.getUTCFullYear();
  let month = String(date.getUTCMonth() + 1).padStart(2, "0");
  let day = String(date.getUTCDate()).padStart(2, "0");
  let hours = String(date.getUTCHours()).padStart(2, "0");
  let minutes = String(date.getUTCMinutes()).padStart(2, "0");
  return year + "-" + month + "-" + day + " " + hours + ":" + minutes + " UTC";
}

function padNumber(value, size) {
  return String(Math.max(0, Number(value) || 0)).padStart(size, "0");
}

function uint16ToBinary(value) {
  let normalized = Number(value) >>> 0;
  return String.fromCharCode(normalized & 255, (normalized >>> 8) & 255);
}

function uint32ToBinary(value) {
  let normalized = Number(value) >>> 0;
  return String.fromCharCode(
    normalized & 255,
    (normalized >>> 8) & 255,
    (normalized >>> 16) & 255,
    (normalized >>> 24) & 255
  );
}

function dateToDosTime(timestamp) {
  let date = new Date(Number(timestamp || Date.now()));
  let hours = date.getHours();
  let minutes = date.getMinutes();
  let seconds = Math.floor(date.getSeconds() / 2);
  return (hours << 11) | (minutes << 5) | seconds;
}

function dateToDosDate(timestamp) {
  let date = new Date(Number(timestamp || Date.now()));
  let year = Math.max(1980, date.getFullYear());
  let month = date.getMonth() + 1;
  let day = date.getDate();
  return ((year - 1980) << 9) | (month << 5) | day;
}

let crc32Table = null;

function getCrc32Table() {
  if (crc32Table) {
    return crc32Table;
  }

  crc32Table = [];
  for (let index = 0; index < 256; index += 1) {
    let value = index;
    for (let bit = 0; bit < 8; bit += 1) {
      if (value & 1) {
        value = 0xedb88320 ^ (value >>> 1);
      } else {
        value = value >>> 1;
      }
    }
    crc32Table[index] = value >>> 0;
  }

  return crc32Table;
}

function crc32Binary(data) {
  let table = getCrc32Table();
  let crc = 0 ^ -1;

  for (let index = 0; index < data.length; index += 1) {
    let byte = data.charCodeAt(index) & 255;
    crc = (crc >>> 8) ^ table[(crc ^ byte) & 255];
  }

  return (crc ^ -1) >>> 0;
}

function createZipBuilder(timestamp) {
  let localParts = [];
  let centralParts = [];
  let offset = 0;
  let dosTime = dateToDosTime(timestamp);
  let dosDate = dateToDosDate(timestamp);

  function appendEntry(entry) {
    let name = String(entry.name || "file.bin");
    let data = String(entry.data || "");
    let crc = crc32Binary(data);
    let size = data.length;

    let localHeader =
      "PK\u0003\u0004" +
      uint16ToBinary(20) +
      uint16ToBinary(0) +
      uint16ToBinary(0) +
      uint16ToBinary(dosTime) +
      uint16ToBinary(dosDate) +
      uint32ToBinary(crc) +
      uint32ToBinary(size) +
      uint32ToBinary(size) +
      uint16ToBinary(name.length) +
      uint16ToBinary(0) +
      name;

    localParts.push(localHeader);
    localParts.push(data);

    let centralHeader =
      "PK\u0001\u0002" +
      uint16ToBinary(20) +
      uint16ToBinary(20) +
      uint16ToBinary(0) +
      uint16ToBinary(0) +
      uint16ToBinary(dosTime) +
      uint16ToBinary(dosDate) +
      uint32ToBinary(crc) +
      uint32ToBinary(size) +
      uint32ToBinary(size) +
      uint16ToBinary(name.length) +
      uint16ToBinary(0) +
      uint16ToBinary(0) +
      uint16ToBinary(0) +
      uint16ToBinary(0) +
      uint32ToBinary(0) +
      uint32ToBinary(offset) +
      name;

    centralParts.push(centralHeader);
    offset += localHeader.length + data.length;
  }

  function toBinary() {
    let entryCount = centralParts.length;
    let centralDirectory = centralParts.join("");
    let endRecord =
      "PK\u0005\u0006" +
      uint16ToBinary(0) +
      uint16ToBinary(0) +
      uint16ToBinary(entryCount) +
      uint16ToBinary(entryCount) +
      uint32ToBinary(centralDirectory.length) +
      uint32ToBinary(offset) +
      uint16ToBinary(0);

    return localParts.join("") + centralDirectory + endRecord;
  }

  return {
    appendEntry: appendEntry,
    toBinary: toBinary,
  };
}

// ── Ticket data fetching ───────────────────────────────────────────────────────

async function fetchTicketData(ticketId) {
  let ticket = await rateLimitedInvoke("get_ticket", { ticket_id: ticketId });
  return {
    id: Number(ticket.id),
    subject: normalizeText(ticket.subject) || ("Ticket #" + ticket.id),
    description: ticket.description || "",
    description_text: ticket.description_text || "",
    status: ticket.status,
    priority: ticket.priority,
    type: normalizeText(ticket.type),
    source: ticket.source,
    tags: Array.isArray(ticket.tags) ? ticket.tags : [],
    group_id: ticket.group_id,
    responder_id: ticket.responder_id,
    requester_id: ticket.requester_id,
    requester: ticket.requester || null,
    custom_fields: ticket.custom_fields || {},
    created_at: ticket.created_at || "",
    updated_at: ticket.updated_at || "",
    due_by: ticket.due_by || "",
    fr_due_by: ticket.fr_due_by || "",
    stats: ticket.stats || {},
  };
}

async function fetchTicketConversations(ticketId) {
  let conversations = await fetchPaginated("get_ticket_conversations", {
    ticket_id: ticketId,
  });

  return conversations.map(function (c) {
    return {
      id: c.id,
      body: c.body || "",
      body_text: c.body_text || "",
      incoming: Boolean(c.incoming),
      private: Boolean(c.private),
      source: c.source,
      user_id: c.user_id,
      from_email: c.from_email || "",
      to_emails: c.to_emails || [],
      created_at: c.created_at || "",
      updated_at: c.updated_at || "",
      attachments: Array.isArray(c.attachments) ? c.attachments : [],
    };
  });
}

async function fetchTicketFieldDefinitions() {
  if (cachedFieldDefinitions) {
    return cachedFieldDefinitions;
  }

  let fields = await fetchPaginated("get_ticket_fields", {});
  cachedFieldDefinitions = fields.map(function (f) {
    return {
      id: f.id,
      name: normalizeText(f.name),
      label: normalizeText(f.label) || normalizeText(f.name),
      type: f.type || "text",
      choices: f.choices || null,
      required: Boolean(f.required_for_agents || f.required_for_customers),
      default: Boolean(f.default),
    };
  });

  return cachedFieldDefinitions;
}

async function resolveAgentName(agentId, cache) {
  if (!agentId) return "Unassigned";
  let key = String(agentId);
  if (cache.has(key)) return cache.get(key);

  try {
    let agent = await rateLimitedInvoke("get_agent", { agent_id: agentId });
    let contact = agent.contact || agent;
    let name = normalizeText(contact.name) || normalizeText(contact.email) || ("Agent #" + agentId);
    cache.set(key, name);
    return name;
  } catch {
    let fallback = "Agent #" + agentId;
    cache.set(key, fallback);
    return fallback;
  }
}

async function resolveContactName(contactId, cache) {
  if (!contactId) return "Unknown";
  let key = String(contactId);
  if (cache.has(key)) return cache.get(key);

  try {
    let contact = await rateLimitedInvoke("get_contact", { contact_id: contactId });
    let name = normalizeText(contact.name) || normalizeText(contact.email) || ("Contact #" + contactId);
    cache.set(key, name);
    return name;
  } catch {
    let fallback = "Contact #" + contactId;
    cache.set(key, fallback);
    return fallback;
  }
}

async function resolveUserName(userId, cache) {
  if (!userId) return "Unknown";
  let key = String(userId);
  if (cache.has(key)) return cache.get(key);

  try {
    let contact = await rateLimitedInvoke("get_contact", { contact_id: userId });
    let name = normalizeText(contact.name) || normalizeText(contact.email) || ("User #" + userId);
    cache.set(key, name);
    return name;
  } catch {
    try {
      let agent = await rateLimitedInvoke("get_agent", { agent_id: userId });
      let agentContact = agent.contact || agent;
      let agentName = normalizeText(agentContact.name) || normalizeText(agentContact.email) || ("User #" + userId);
      cache.set(key, agentName);
      return agentName;
    } catch {
      let fallback = "User #" + userId;
      cache.set(key, fallback);
      return fallback;
    }
  }
}

// ── Ticket search ──────────────────────────────────────────────────────────────

function validateSearchFilters(filters) {
  if (!filters || !filters.created_after || !filters.created_before) {
    return;
  }

  let startTime = new Date(filters.created_after + "T00:00:00").getTime();
  let endTime = new Date(filters.created_before + "T00:00:00").getTime();

  if (Number.isFinite(startTime) && Number.isFinite(endTime) && startTime > endTime) {
    throw new Error("Created After must be on or before Created Before.");
  }
}

function buildSearchQuery(filters) {
  let parts = [];

  if (filters.subject) {
    parts.push("subject:'" + String(filters.subject).trim().replace(/'/g, "\\'") + "'");
  }
  if (filters.status) {
    parts.push("status:" + filters.status);
  }
  if (filters.priority) {
    parts.push("priority:" + filters.priority);
  }
  if (filters.created_after) {
    parts.push("created_at:>'" + filters.created_after + "'");
  }
  if (filters.created_before) {
    parts.push("created_at:<'" + filters.created_before + "'");
  }

  return parts.length ? parts.join(" AND ") : "";
}

function ticketMatchesFilters(ticket, filters) {
  if (!ticket) return false;

  if (filters.subject) {
    let subject = normalizeText(ticket.subject).toLowerCase();
    if (subject.indexOf(normalizeText(filters.subject).toLowerCase()) === -1) {
      return false;
    }
  }

  if (filters.status && String(ticket.status) !== String(filters.status)) {
    return false;
  }

  if (filters.priority && String(ticket.priority) !== String(filters.priority)) {
    return false;
  }

  if (filters.created_after) {
    let createdAt = new Date(ticket.created_at || "").getTime();
    let afterTime = new Date(filters.created_after).getTime();
    if (Number.isFinite(createdAt) && Number.isFinite(afterTime) && createdAt < afterTime) {
      return false;
    }
  }

  if (filters.created_before) {
    let createdAt = new Date(ticket.created_at || "").getTime();
    let beforeTime = new Date(filters.created_before).getTime();
    if (Number.isFinite(createdAt) && Number.isFinite(beforeTime) && createdAt > beforeTime + 86400000) {
      return false;
    }
  }

  return true;
}

async function searchTicketsQuery(filters, page) {
  let ticketId = normalizeText(filters.ticket_id);
  if (ticketId) {
    if (!/^\d+$/.test(ticketId)) {
      return { total: 0, tickets: [] };
    }

    try {
      let ticket = await rateLimitedInvoke("get_ticket", { ticket_id: Number(ticketId) });
      return ticketMatchesFilters(ticket, filters)
        ? { total: 1, tickets: [ticket] }
        : { total: 0, tickets: [] };
    } catch (error) {
      if (error && error.status === 404) {
        return { total: 0, tickets: [] };
      }
      throw error;
    }
  }

  if (filters.subject) {
    return searchTicketsByListing(filters, page);
  }

  return searchTicketsByApi(filters, page);
}

async function searchTicketsByApi(filters, page) {
  let queryString = buildSearchQuery(filters);
  if (!queryString) {
    let tickets = await rateLimitedInvoke("list_tickets", { page: page || 1, per_page: 30 });
    return {
      total: Array.isArray(tickets) ? tickets.length : 0,
      tickets: Array.isArray(tickets) ? tickets : [],
    };
  }

  let encodedQuery = encodeURIComponent("\"" + queryString + "\"");
  let result;

  try {
    result = await rateLimitedInvoke("search_tickets", {
      query: encodedQuery,
      page: page || 1,
    });
  } catch (error) {
    console.error("Ticket subject/search API failed", {
      filters: filters,
      queryString: queryString,
      encodedQuery: encodedQuery,
      page: page || 1,
      status: error && error.status,
      message: error && error.message,
      response: error && (error.response || error.responseText || error.body || ""),
      headers: error && error.headers,
      stack: error && error.stack,
    });

    let debugError = new Error("Search query failed for: " + queryString);
    debugError.status = error && error.status;
    debugError.detail = buildErrorMessage(error, "Search query failed.");
    debugError.response = error && (error.response || error.responseText || error.body || "");
    debugError.headers = error && error.headers;
    debugError.queryString = queryString;
    debugError.encodedQuery = encodedQuery;
    debugError.stack = error && error.stack;
    throw debugError;
  }

  if (result && result.results) {
    return {
      total: result.total || result.results.length,
      tickets: result.results,
    };
  }

  return { total: 0, tickets: [] };
}

async function searchTicketsByListing(filters, page) {
  let matches = [];
  let targetPage = Math.max(1, Number(page) || 1);
  let targetCount = targetPage * 30;

  console.info("Subject search is using list_tickets scan because Freshdesk search API does not support subject filters.", {
    filters: filters,
    page: targetPage,
    scanPages: SUBJECT_SEARCH_SCAN_PAGES,
  });

  for (let currentPage = 1; currentPage <= SUBJECT_SEARCH_SCAN_PAGES; currentPage += 1) {
    let tickets = await rateLimitedInvoke("list_tickets", {
      page: currentPage,
      per_page: 30,
    });

    let pageItems = Array.isArray(tickets) ? tickets : [];
    if (!pageItems.length) {
      break;
    }

    pageItems.forEach(function (ticket) {
      if (ticketMatchesFilters(ticket, filters)) {
        matches.push(ticket);
      }
    });

    if (matches.length >= targetCount && pageItems.length < 30) {
      break;
    }

    if (pageItems.length < 30) {
      break;
    }
  }

  let start = (targetPage - 1) * 30;
  return {
    total: matches.length,
    tickets: matches.slice(start, start + 30),
  };
}

// ── Conversation filtering ─────────────────────────────────────────────────────

function classifyConversation(conversation) {
  if (conversation.private) {
    return "private_note";
  }
  if (conversation.incoming) {
    return "reply";
  }
  if (conversation.source === 2 || conversation.source === 0) {
    return "public_note";
  }
  return "reply";
}

function filterConversations(conversations, template) {
  let filtered = conversations.filter(function (c) {
    let type = classifyConversation(c);

    if (template.view_mode === "customer" && type === "private_note") {
      return false;
    }

    if (type === "reply" && !template.include_replies) {
      return false;
    }
    if (type === "public_note" && !template.include_public_notes) {
      return false;
    }
    if (type === "private_note" && !template.include_private_notes) {
      return false;
    }

    return true;
  });

  filtered.sort(function (a, b) {
    return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
  });

  return filtered;
}

// ── HTML / Text processing (reused from KB app) ───────────────────────────────

function decodeHtmlEntities(text) {
  return String(text || "")
    .replace(/&#(\d+);/g, function (_, code) { return String.fromCharCode(Number(code)); })
    .replace(/&#x([0-9a-f]+);/gi, function (_, code) { return String.fromCharCode(parseInt(code, 16)); })
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, "\"")
    .replace(/&#39;/gi, "'");
}

function htmlToPlainText(html) {
  let withBreaks = String(html || "")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<\/div>/gi, "\n")
    .replace(/<\/h[1-6]>/gi, "\n")
    .replace(/<li[^>]*>/gi, "- ")
    .replace(/<\/li>/gi, "\n")
    .replace(/<\/tr>/gi, "\n")
    .replace(/<\/table>/gi, "\n\n")
    .replace(/<\/ul>/gi, "\n")
    .replace(/<\/ol>/gi, "\n")
    .replace(/<[^>]+>/g, "");

  return decodeHtmlEntities(withBreaks)
    .replace(/\r/g, "")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function sanitizePdfText(text) {
  return String(text || "")
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/["\u201C\u201D]/g, "\"")
    .replace(/['\u2018\u2019]/g, "'")
    .replace(/[\u2022]/g, "-")
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/[^\x09\x0A\x0D\x20-\x7E\xA0-\xFF]/g, "");
}

function escapePdfString(value) {
  return String(value || "")
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)");
}

function getLatin1ByteLength(text) {
  return String(text || "").length;
}

function encodeLatin1ToBase64(text) {
  let input = String(text || "");
  let alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  let output = "";

  for (let index = 0; index < input.length; index += 3) {
    let byte1 = input.charCodeAt(index) & 255;
    let hasByte2 = index + 1 < input.length;
    let hasByte3 = index + 2 < input.length;
    let byte2 = hasByte2 ? input.charCodeAt(index + 1) & 255 : 0;
    let byte3 = hasByte3 ? input.charCodeAt(index + 2) & 255 : 0;

    let combined = (byte1 << 16) | (byte2 << 8) | byte3;
    output += alphabet[(combined >> 18) & 63];
    output += alphabet[(combined >> 12) & 63];
    output += hasByte2 ? alphabet[(combined >> 6) & 63] : "=";
    output += hasByte3 ? alphabet[combined & 63] : "=";
  }

  return output;
}

// ── PDF text metrics ───────────────────────────────────────────────────────────

function colorToPdf(hex) {
  let value = String(hex || "#17324d").replace("#", "");
  let normalized = value.length === 3
    ? value.split("").map(function (c) { return c + c; }).join("")
    : value;
  let red = parseInt(normalized.slice(0, 2), 16) / 255;
  let green = parseInt(normalized.slice(2, 4), 16) / 255;
  let blue = parseInt(normalized.slice(4, 6), 16) / 255;
  return red.toFixed(3) + " " + green.toFixed(3) + " " + blue.toFixed(3);
}

const HELVETICA_WIDTHS = [278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584];
const HELVETICA_BOLD_WIDTHS = [278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,333,333,584,584,584,611,975,722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,667,778,722,667,611,722,667,944,667,667,611,333,278,333,584,556,333,556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,611,611,389,556,333,611,556,778,556,556,500,389,280,389,584];

function estimateTextWidth(text, fontSize, fontKey) {
  let safeText = sanitizePdfText(text);
  let isBold = fontKey === "F2" || fontKey === "F4";
  let isMono = fontKey === "F5";
  let widths = isBold ? HELVETICA_BOLD_WIDTHS : HELVETICA_WIDTHS;
  let total = 0;
  for (let i = 0; i < safeText.length; i++) {
    let code = safeText.charCodeAt(i);
    if (isMono) {
      total += 600;
    } else if (code >= 32 && code <= 126) {
      total += widths[code - 32];
    } else {
      total += 500;
    }
  }
  return total * fontSize / 1000;
}

// ── PDF block system ───────────────────────────────────────────────────────────

function buildTextStyle(block, formatState) {
  let isMono = block.baseMono || formatState.mono > 0;
  let isBold = block.baseBold || formatState.bold > 0;
  let isItalic = block.baseItalic || formatState.italic > 0;

  let fontKey = "F1";
  if (isMono) {
    fontKey = "F5";
  } else if (isBold && isItalic) {
    fontKey = "F4";
  } else if (isBold) {
    fontKey = "F2";
  } else if (isItalic) {
    fontKey = "F3";
  }

  return {
    fontKey: fontKey,
    color: formatState.link > 0 ? "#2563eb" : block.color,
    underline: formatState.link > 0,
  };
}

function createBlock(kind, overrides) {
  let defaults = {
    kind: kind,
    fontSize: 11,
    lineHeight: 15,
    color: "#284766",
    marginTop: 0,
    marginBottom: 10,
    indent: 0,
    markerText: "",
    keepTogether: false,
    preserveWhitespace: false,
    baseBold: false,
    baseItalic: false,
    baseMono: false,
    segments: [],
  };

  if (kind === "title") {
    return Object.assign({}, defaults, {
      fontSize: 24,
      lineHeight: 30,
      color: "#17324d",
      marginBottom: 14,
      baseBold: true,
      keepTogether: true,
    }, overrides);
  }

  if (kind === "subtitle") {
    return Object.assign({}, defaults, {
      fontSize: 13,
      lineHeight: 18,
      color: "#5b6f86",
      marginBottom: 8,
    }, overrides);
  }

  if (kind === "heading1") {
    return Object.assign({}, defaults, {
      fontSize: 20,
      lineHeight: 25,
      color: "#17324d",
      marginTop: 8,
      marginBottom: 10,
      baseBold: true,
      keepTogether: true,
    }, overrides);
  }

  if (kind === "heading2") {
    return Object.assign({}, defaults, {
      fontSize: 16,
      lineHeight: 21,
      color: "#17324d",
      marginTop: 8,
      marginBottom: 8,
      baseBold: true,
      keepTogether: true,
    }, overrides);
  }

  if (kind === "heading3") {
    return Object.assign({}, defaults, {
      fontSize: 13,
      lineHeight: 18,
      color: "#17324d",
      marginTop: 6,
      marginBottom: 6,
      baseBold: true,
      keepTogether: true,
    }, overrides);
  }

  if (kind === "meta") {
    return Object.assign({}, defaults, {
      fontSize: 10,
      lineHeight: 14,
      color: "#6b7c93",
      marginBottom: 4,
      keepTogether: true,
    }, overrides);
  }

  if (kind === "quote") {
    return Object.assign({}, defaults, {
      fontSize: 11,
      lineHeight: 16,
      color: "#44586d",
      marginTop: 4,
      marginBottom: 10,
      indent: 18,
      baseItalic: true,
    }, overrides);
  }

  if (kind === "listItem") {
    return Object.assign({}, defaults, {
      fontSize: 11,
      lineHeight: 15,
      color: "#284766",
      marginBottom: 4,
      indent: 18,
    }, overrides);
  }

  if (kind === "pre") {
    return Object.assign({}, defaults, {
      fontSize: 10,
      lineHeight: 14,
      color: "#17324d",
      marginTop: 4,
      marginBottom: 10,
      baseMono: true,
      preserveWhitespace: true,
    }, overrides);
  }

  if (kind === "rule") {
    return Object.assign({}, defaults, {
      lineColor: "#d9e3ee",
      marginTop: 10,
      marginBottom: 12,
      keepTogether: true,
    }, overrides);
  }

  return Object.assign({}, defaults, overrides);
}

// ── HTML parser ────────────────────────────────────────────────────────────────

function flushCurrentBlock(blocks, state) {
  let block = state.currentBlock;
  if (!block) return;

  let hasVisibleText = block.segments.some(function (segment) {
    return segment && typeof segment.text === "string" && segment.text.replace(/\s+/g, "").length > 0;
  });

  if (block.kind === "rule" || hasVisibleText || block.markerText) {
    blocks.push(block);
  }

  state.currentBlock = null;
}

function normalizeInlineHtmlText(text) {
  let decoded = decodeHtmlEntities(text).replace(/\r/g, "").replace(/\s+/g, " ");
  if (!decoded) return "";
  if (!decoded.trim()) return " ";
  return decoded;
}

function ensureCurrentBlock(blocks, state, kind, overrides) {
  if (!state.currentBlock) {
    state.currentBlock = createBlock(kind, overrides);
  }
  return state.currentBlock;
}

function addSegment(blocks, state, text) {
  if (!text) return;

  let block =
    state.currentBlock ||
    ensureCurrentBlock(blocks, state, state.quoteDepth > 0 ? "quote" : "paragraph", {
      indent: state.quoteDepth * 18,
    });
  let style = buildTextStyle(block, state.format);
  let previousSegment = block.segments[block.segments.length - 1];
  let normalizedText = text;

  if (previousSegment && /\s$/.test(previousSegment.text || "") && /^\s+/.test(normalizedText)) {
    normalizedText = normalizedText.replace(/^\s+/, " ");
  }

  if (previousSegment && /^[,.;:!?%)\]}]/.test(normalizedText)) {
    previousSegment.text = String(previousSegment.text || "").replace(/\s+$/, "");
  }

  if (
    previousSegment &&
    /[(\[{]$/.test(String(previousSegment.text || "")) &&
    /^\s+/.test(normalizedText)
  ) {
    normalizedText = normalizedText.replace(/^\s+/, "");
  }

  if (/^\s+[,.;:!?%)\]}]/.test(normalizedText)) {
    normalizedText = normalizedText.replace(/^\s+/, "");
  }

  if (/^\s+$/.test(normalizedText) && previousSegment && /\s$/.test(previousSegment.text || "")) {
    return;
  }

  block.segments.push({
    text: normalizedText,
    fontKey: style.fontKey,
    color: style.color,
    underline: style.underline,
  });
}

function parseAttributes(tagText) {
  let attributes = {};
  let attrRegex = /([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*=\s*"([^"]*)"/g;
  let match = attrRegex.exec(tagText);
  while (match) {
    attributes[match[1].toLowerCase()] = match[2];
    match = attrRegex.exec(tagText);
  }
  return attributes;
}

function parseHtmlToBlocks(html) {
  let source = String(html || "");
  if (!source.trim()) return [];

  let blocks = [];
  let state = {
    currentBlock: null,
    format: { bold: 0, italic: 0, mono: 0, link: 0 },
    listStack: [],
    quoteDepth: 0,
  };
  let tokens = source.match(/<\/?[^>]+>|[^<]+/g) || [];

  tokens.forEach(function (token) {
    if (token.startsWith("<")) {
      let isClosing = /^<\//.test(token);
      let nameMatch = token.match(/^<\/?\s*([a-zA-Z0-9]+)/);
      let tagName = nameMatch ? nameMatch[1].toLowerCase() : "";
      let attributes = parseAttributes(token);

      if (isClosing) {
        if (tagName === "p" || tagName === "div" || tagName === "section" || tagName === "article" ||
            tagName === "li" || tagName === "tr" || /^h[1-6]$/.test(tagName) || tagName === "pre") {
          flushCurrentBlock(blocks, state);
        } else if (tagName === "ul" || tagName === "ol") {
          flushCurrentBlock(blocks, state);
          state.listStack.pop();
        } else if (tagName === "blockquote") {
          flushCurrentBlock(blocks, state);
          state.quoteDepth = Math.max(0, state.quoteDepth - 1);
        } else if (tagName === "strong" || tagName === "b") {
          state.format.bold = Math.max(0, state.format.bold - 1);
        } else if (tagName === "em" || tagName === "i") {
          state.format.italic = Math.max(0, state.format.italic - 1);
        } else if (tagName === "code") {
          state.format.mono = Math.max(0, state.format.mono - 1);
        } else if (tagName === "a") {
          state.format.link = Math.max(0, state.format.link - 1);
        } else if (tagName === "th") {
          state.format.bold = Math.max(0, state.format.bold - 1);
        }
        return;
      }

      if (tagName === "br") {
        addSegment(blocks, state, "\n");
        return;
      }

      if (tagName === "hr") {
        flushCurrentBlock(blocks, state);
        blocks.push(createBlock("rule"));
        return;
      }

      if (tagName === "p" || tagName === "div" || tagName === "section" || tagName === "article") {
        flushCurrentBlock(blocks, state);
        state.currentBlock = createBlock(state.quoteDepth > 0 ? "quote" : "paragraph", {
          indent: state.quoteDepth * 18,
        });
        return;
      }

      if (/^h[1-6]$/.test(tagName)) {
        flushCurrentBlock(blocks, state);
        let level = Number(tagName.slice(1));
        let headingKind = level === 1 ? "heading1" : level === 2 ? "heading2" : "heading3";
        state.currentBlock = createBlock(headingKind, {
          indent: state.quoteDepth * 18,
        });
        return;
      }

      if (tagName === "blockquote") {
        flushCurrentBlock(blocks, state);
        state.quoteDepth += 1;
        state.currentBlock = createBlock("quote", {
          indent: state.quoteDepth * 18,
        });
        return;
      }

      if (tagName === "ul" || tagName === "ol") {
        flushCurrentBlock(blocks, state);
        state.listStack.push({ type: tagName, index: 0 });
        return;
      }

      if (tagName === "li") {
        flushCurrentBlock(blocks, state);
        let list = state.listStack[state.listStack.length - 1] || { type: "ul", index: 0 };
        if (list.type === "ol") {
          list.index += 1;
        }
        let markerText = list.type === "ol" ? (list.index + ". ") : "\u2022 ";
        state.currentBlock = createBlock("listItem", {
          indent: state.quoteDepth * 18 + Math.max(0, state.listStack.length - 1) * 16,
          markerText: markerText,
        });
        return;
      }

      if (tagName === "pre") {
        flushCurrentBlock(blocks, state);
        state.currentBlock = createBlock("pre", {
          indent: state.quoteDepth * 18,
        });
        return;
      }

      if (tagName === "tr") {
        flushCurrentBlock(blocks, state);
        state.currentBlock = createBlock("paragraph", {
          indent: state.quoteDepth * 18,
          marginBottom: 6,
        });
        return;
      }

      if (tagName === "td" || tagName === "th") {
        let tableBlock = ensureCurrentBlock(blocks, state, "paragraph", {
          indent: state.quoteDepth * 18,
          marginBottom: 6,
        });
        if (tableBlock.segments.length) {
          addSegment(blocks, state, " | ");
        }
        if (tagName === "th") {
          state.format.bold += 1;
        }
        return;
      }

      if (tagName === "strong" || tagName === "b") {
        state.format.bold += 1;
        return;
      }
      if (tagName === "em" || tagName === "i") {
        state.format.italic += 1;
        return;
      }
      if (tagName === "code") {
        state.format.mono += 1;
        return;
      }
      if (tagName === "a" && attributes.href) {
        state.format.link += 1;
      }
      return;
    }

    let normalizedText = state.currentBlock && state.currentBlock.preserveWhitespace
      ? decodeHtmlEntities(token).replace(/\r/g, "")
      : normalizeInlineHtmlText(token);

    if (normalizedText) {
      addSegment(blocks, state, normalizedText);
    }
  });

  flushCurrentBlock(blocks, state);
  return blocks;
}

// ── Text wrapping ──────────────────────────────────────────────────────────────

function splitSegmentText(segment, preserveWhitespace) {
  let input = String(segment.text || "");
  let parts = input.split(/(\n)/);
  let tokens = [];

  parts.forEach(function (part) {
    if (!part) return;
    if (part === "\n") {
      tokens.push({ type: "newline" });
      return;
    }

    if (preserveWhitespace) {
      part.split(/([ \t]+)/).forEach(function (piece) {
        if (!piece) return;
        if (/^[ \t]+$/.test(piece)) {
          tokens.push({ type: "space", text: piece.replace(/\t/g, "  "), style: segment });
        } else {
          tokens.push({ type: "word", text: piece, style: segment });
        }
      });
      return;
    }

    part.split(/(\s+)/).forEach(function (piece) {
      if (!piece) return;
      if (/^\s+$/.test(piece)) {
        tokens.push({ type: "space", text: " ", style: segment });
      } else {
        tokens.push({ type: "word", text: piece, style: segment });
      }
    });
  });

  return tokens;
}

function breakWordToFit(text, style, width) {
  let safeText = sanitizePdfText(text);
  if (estimateTextWidth(safeText, style.fontSize || 11, style.fontKey || "F1") <= width) {
    return [safeText];
  }

  let slices = [];
  let current = "";

  for (let ci = 0; ci < safeText.length; ci++) {
    let ch = safeText[ci];
    let next = current + ch;
    if (current && estimateTextWidth(next, style.fontSize || 11, style.fontKey || "F1") > width) {
      slices.push(current);
      current = ch;
    } else {
      current = next;
    }
  }

  if (current) {
    slices.push(current);
  }

  return slices.length ? slices : [safeText];
}

function mergeLineRuns(runs) {
  let merged = [];

  runs.forEach(function (run) {
    if (!run.text) return;
    let previous = merged[merged.length - 1];
    if (
      previous &&
      previous.fontKey === run.fontKey &&
      previous.color === run.color &&
      previous.underline === run.underline
    ) {
      previous.text += run.text;
      return;
    }
    merged.push(Object.assign({}, run));
  });

  return merged;
}

function trimLineRuns(runs) {
  let trimmed = runs.map(function (run) { return Object.assign({}, run); });

  while (trimmed.length) {
    trimmed[0].text = trimmed[0].text.replace(/^\s+/, "");
    if (trimmed[0].text) break;
    trimmed.shift();
  }

  while (trimmed.length) {
    let lastIndex = trimmed.length - 1;
    trimmed[lastIndex].text = trimmed[lastIndex].text.replace(/\s+$/, "");
    if (trimmed[lastIndex].text) break;
    trimmed.pop();
  }

  return trimmed;
}

function buildWrappedLines(block) {
  let markerWidth = block.markerText
    ? estimateTextWidth(block.markerText, block.fontSize, block.baseBold ? "F2" : "F1") + 6
    : 0;
  let availableWidth = CONTENT_WIDTH - block.indent - markerWidth;
  let tokens = [];

  block.segments.forEach(function (segment) {
    tokens.push.apply(tokens, splitSegmentText(segment, block.preserveWhitespace));
  });

  if (!tokens.length) {
    return { markerWidth: markerWidth, lines: [] };
  }

  let lines = [];
  let currentRuns = [];
  let currentWidth = 0;

  function pushLine() {
    lines.push(trimLineRuns(mergeLineRuns(currentRuns)));
    currentRuns = [];
    currentWidth = 0;
  }

  tokens.forEach(function (token) {
    if (token.type === "newline") {
      pushLine();
      return;
    }

    let style = {
      fontKey: token.style.fontKey,
      color: token.style.color,
      underline: token.style.underline,
      fontSize: block.fontSize,
    };
    let tokenText = token.type === "space" ? token.text : sanitizePdfText(token.text);
    let tokenWidth = estimateTextWidth(tokenText, block.fontSize, style.fontKey);

    if (token.type === "space") {
      if (!currentRuns.length) return;
      currentRuns.push(Object.assign({}, style, { text: " " }));
      currentWidth += tokenWidth;
      return;
    }

    if (currentWidth + tokenWidth <= availableWidth || !currentRuns.length) {
      if (!currentRuns.length && tokenWidth > availableWidth) {
        let pieces = breakWordToFit(tokenText, style, availableWidth);
        pieces.forEach(function (piece, idx) {
          if (idx > 0) pushLine();
          currentRuns.push(Object.assign({}, style, { text: piece }));
          currentWidth += estimateTextWidth(piece, block.fontSize, style.fontKey);
        });
        return;
      }

      currentRuns.push(Object.assign({}, style, { text: tokenText }));
      currentWidth += tokenWidth;
      return;
    }

    pushLine();

    if (tokenWidth > availableWidth) {
      let wordPieces = breakWordToFit(tokenText, style, availableWidth);
      wordPieces.forEach(function (piece, idx) {
        if (idx > 0) pushLine();
        currentRuns.push(Object.assign({}, style, { text: piece }));
        currentWidth += estimateTextWidth(piece, block.fontSize, style.fontKey);
      });
      return;
    }

    currentRuns.push(Object.assign({}, style, { text: tokenText }));
    currentWidth += tokenWidth;
  });

  if (currentRuns.length) {
    pushLine();
  }

  return { markerWidth: markerWidth, lines: lines };
}

// ── PDF page rendering ─────────────────────────────────────────────────────────

function createPdfPage() {
  return { operations: [], cursorY: PAGE_HEIGHT - PAGE_MARGIN };
}

function addPdfPage(pages) {
  let page = createPdfPage();
  pages.push(page);
  return page;
}

function appendTextOperation(page, x, y, run, fontSize) {
  page.operations.push(
    "BT",
    "/" + run.fontKey + " " + fontSize + " Tf",
    colorToPdf(run.color) + " rg",
    "1 0 0 1 " + x.toFixed(2) + " " + y.toFixed(2) + " Tm",
    "(" + escapePdfString(sanitizePdfText(run.text)) + ") Tj",
    "ET"
  );

  if (run.underline) {
    let underlineY = y - 1.5;
    let underlineWidth = estimateTextWidth(run.text, fontSize, run.fontKey);
    page.operations.push(
      colorToPdf(run.color) + " RG",
      "1 w",
      x.toFixed(2) + " " + underlineY.toFixed(2) + " m",
      (x + underlineWidth).toFixed(2) + " " + underlineY.toFixed(2) + " l",
      "S"
    );
  }
}

function appendRuleOperation(page, y, color, fromX, toX, width) {
  page.operations.push(
    colorToPdf(color) + " RG",
    width.toFixed(2) + " w",
    fromX.toFixed(2) + " " + y.toFixed(2) + " m",
    toX.toFixed(2) + " " + y.toFixed(2) + " l",
    "S"
  );
}

function appendCreatedDate(pages, timestamp) {
  let fontSize = 7;
  let color = "#7b8ea5";
  let headerY = PAGE_HEIGHT - PAGE_MARGIN + 14;
  let dateText = "Created: " + formatDateTime(timestamp);

  pages.forEach(function (page) {
    let textWidth = estimateTextWidth(dateText, fontSize, "F1");
    let x = PAGE_WIDTH - PAGE_MARGIN - textWidth;

    appendTextOperation(page, x, headerY, {
      fontKey: "F1",
      color: color,
      underline: false,
      text: dateText,
    }, fontSize);
  });
}

function appendPageNumbers(pages, format) {
  let totalPages = pages.length;
  let fontSize = 9;
  let color = "#7b8ea5";
  let footerY = 20;

  pages.forEach(function (page, index) {
    let pageNum = index + 1;
    let footerText;

    switch (format) {
      case "page_only":
        footerText = String(pageNum);
        break;
      case "page_dash_total":
        footerText = pageNum + " - " + totalPages;
        break;
      case "page_of_word":
        footerText = "Page " + pageNum + " of " + totalPages;
        break;
      default:
        footerText = pageNum + "/" + totalPages;
    }

    let textWidth = estimateTextWidth(footerText, fontSize, "F1");
    let x = (PAGE_WIDTH - textWidth) / 2;

    appendTextOperation(page, x, footerY, {
      fontKey: "F1",
      color: color,
      underline: false,
      text: footerText,
    }, fontSize);
  });
}

function renderBlockToPages(block, pages, currentPageRef) {
  let currentPage = currentPageRef.page;

  if (block.kind === "rule") {
    if (currentPage.cursorY - block.marginTop - 4 - block.marginBottom < PAGE_MARGIN) {
      currentPage = addPdfPage(pages);
      currentPageRef.page = currentPage;
    }

    currentPage.cursorY -= block.marginTop;
    appendRuleOperation(currentPage, currentPage.cursorY, block.lineColor, PAGE_MARGIN, PAGE_WIDTH - PAGE_MARGIN, 1);
    currentPage.cursorY -= 4 + block.marginBottom;
    return;
  }

  let wrapped = buildWrappedLines(block);
  if (!wrapped.lines.length) return;

  let blockHeight = wrapped.lines.length * block.lineHeight;
  if (
    block.keepTogether &&
    currentPage.cursorY - block.marginTop - blockHeight - block.marginBottom < PAGE_MARGIN &&
    currentPage.operations.length
  ) {
    currentPage = addPdfPage(pages);
    currentPageRef.page = currentPage;
  }

  currentPage.cursorY -= block.marginTop;

  wrapped.lines.forEach(function (lineRuns, lineIndex) {
    if (currentPage.cursorY - block.lineHeight < PAGE_MARGIN) {
      currentPage = addPdfPage(pages);
      currentPageRef.page = currentPage;
    }

    let markerX = PAGE_MARGIN + block.indent;
    let textX = markerX + wrapped.markerWidth;
    let baselineY = currentPage.cursorY;

    if (lineIndex === 0 && block.markerText) {
      appendTextOperation(currentPage, markerX, baselineY, {
        fontKey: "F2",
        color: block.color,
        underline: false,
        text: block.markerText,
      }, block.fontSize);
    }

    let runX = textX;
    lineRuns.forEach(function (run) {
      appendTextOperation(currentPage, runX, baselineY, run, block.fontSize);
      runX += estimateTextWidth(run.text, block.fontSize, run.fontKey);
    });

    if (block.kind === "quote") {
      appendRuleOperation(
        currentPage,
        baselineY + 2,
        "#d3dee8",
        PAGE_MARGIN + block.indent - 10,
        PAGE_MARGIN + block.indent - 10,
        2
      );
    }

    currentPage.cursorY -= block.lineHeight;
  });

  currentPage.cursorY -= block.marginBottom;
}

function buildPdfFromSections(sections, createdAt, template) {
  let pages = [];
  let currentPageRef = { page: addPdfPage(pages) };

  sections.forEach(function (section, index) {
    if (section.pageBreakBefore && (index > 0 || currentPageRef.page.operations.length)) {
      currentPageRef.page = addPdfPage(pages);
    }

    section.blocks.forEach(function (block) {
      renderBlockToPages(block, pages, currentPageRef);
    });
  });

  appendCreatedDate(pages, createdAt);

  let showPageNumbers = !template || template.show_page_numbers !== false;
  if (showPageNumbers) {
    let pageNumFormat = (template && template.page_number_format) || "page_of_total";
    appendPageNumbers(pages, pageNumFormat);
  }

  let objects = [];
  objects[1] = "";
  objects[2] = "";
  objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
  objects[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>";
  objects[5] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique >>";
  objects[6] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-BoldOblique >>";
  objects[7] = "<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>";

  let pageRefs = [];
  let nextObjectId = 8;

  pages.forEach(function (page) {
    let contentObjectId = nextObjectId;
    let pageObjectId = nextObjectId + 1;
    let stream = page.operations.join("\n");
    let length = getLatin1ByteLength(stream);

    objects[contentObjectId] = "<< /Length " + length + " >>\nstream\n" + stream + "\nendstream";
    objects[pageObjectId] =
      "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + PAGE_WIDTH + " " + PAGE_HEIGHT + "] " +
      "/Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R /F4 6 0 R /F5 7 0 R >> >> " +
      "/Contents " + contentObjectId + " 0 R >>";
    pageRefs.push(pageObjectId + " 0 R");
    nextObjectId += 2;
  });

  objects[2] = "<< /Type /Pages /Count " + pages.length + " /Kids [" + pageRefs.join(" ") + "] >>";
  objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";

  let pdf = "%PDF-1.4\n%\xFF\xFF\xFF\xFF\n";
  let offsets = [0];

  for (let objectId = 1; objectId < objects.length; objectId += 1) {
    offsets[objectId] = getLatin1ByteLength(pdf);
    pdf += objectId + " 0 obj\n" + objects[objectId] + "\nendobj\n";
  }

  let xrefOffset = getLatin1ByteLength(pdf);
  pdf += "xref\n0 " + objects.length + "\n";
  pdf += "0000000000 65535 f \n";

  for (let oid = 1; oid < objects.length; oid += 1) {
    pdf += String(offsets[oid]).padStart(10, "0") + " 00000 n \n";
  }

  pdf += "trailer\n<< /Size " + objects.length + " /Root 1 0 R >>\nstartxref\n" + xrefOffset + "\n%%EOF";
  return pdf;
}

// ── Ticket PDF section builders ────────────────────────────────────────────────

function buildDetailFieldBlock(label, value) {
  return createBlock("meta", {
    marginBottom: 6,
    segments: [
      { text: sanitizePdfText(label + ": "), fontKey: "F2", color: "#17324d", underline: false },
      { text: sanitizePdfText(String(value || "-")), fontKey: "F1", color: "#284766", underline: false },
    ],
  });
}

function buildHeaderSection(ticket, template) {
  let blocks = [];
  let headerFields = template.visible_header_fields || ["subject", "ticket_id"];

  if (headerFields.indexOf("subject") !== -1) {
    blocks.push(createBlock("title", {
      segments: [{ text: sanitizePdfText(ticket.subject), fontKey: "F2", color: "#17324d", underline: false }],
    }));
  }

  if (headerFields.indexOf("ticket_id") !== -1) {
    blocks.push(createBlock("subtitle", {
      segments: [{ text: sanitizePdfText("Ticket #" + ticket.id), fontKey: "F1", color: "#5b6f86", underline: false }],
    }));
  }

  if (!blocks.length) return { pageBreakBefore: false, blocks: [] };

  blocks.push(createBlock("rule"));
  return { pageBreakBefore: false, blocks: blocks };
}

function buildDetailsSection(ticket, fieldDefs, template, agentName, requesterName) {
  let blocks = [];
  let fields = template.visible_detail_fields || [];
  let dateFormat = template.date_format || "DD MMM YYYY HH:mm";

  if (fields.indexOf("status") !== -1) {
    blocks.push(buildDetailFieldBlock("Status", resolveStatusLabel(ticket.status)));
  }
  if (fields.indexOf("priority") !== -1) {
    blocks.push(buildDetailFieldBlock("Priority", resolvePriorityLabel(ticket.priority)));
  }
  if (fields.indexOf("type") !== -1 && ticket.type) {
    blocks.push(buildDetailFieldBlock("Type", ticket.type));
  }
  if (fields.indexOf("source") !== -1) {
    blocks.push(buildDetailFieldBlock("Source", resolveSourceLabel(ticket.source)));
  }
  if (fields.indexOf("tags") !== -1 && ticket.tags.length) {
    blocks.push(buildDetailFieldBlock("Tags", ticket.tags.join(", ")));
  }
  if (fields.indexOf("requester") !== -1) {
    blocks.push(buildDetailFieldBlock("Requester", requesterName));
  }
  if (fields.indexOf("agent") !== -1) {
    blocks.push(buildDetailFieldBlock("Agent", agentName));
  }
  if (fields.indexOf("created_at") !== -1) {
    blocks.push(buildDetailFieldBlock("Created", formatTicketDate(ticket.created_at, dateFormat)));
  }
  if (fields.indexOf("updated_at") !== -1) {
    blocks.push(buildDetailFieldBlock("Updated", formatTicketDate(ticket.updated_at, dateFormat)));
  }
  if (fields.indexOf("due_by") !== -1 && ticket.due_by) {
    blocks.push(buildDetailFieldBlock("Due By", formatTicketDate(ticket.due_by, dateFormat)));
  }
  if (fields.indexOf("resolved_at") !== -1 && ticket.stats && ticket.stats.resolved_at) {
    blocks.push(buildDetailFieldBlock("Resolved", formatTicketDate(ticket.stats.resolved_at, dateFormat)));
  }
  if (fields.indexOf("closed_at") !== -1 && ticket.stats && ticket.stats.closed_at) {
    blocks.push(buildDetailFieldBlock("Closed", formatTicketDate(ticket.stats.closed_at, dateFormat)));
  }
  if (fields.indexOf("first_responded_at") !== -1 && ticket.stats && ticket.stats.first_responded_at) {
    blocks.push(buildDetailFieldBlock("First Response", formatTicketDate(ticket.stats.first_responded_at, dateFormat)));
  }

  if (!blocks.length) return { pageBreakBefore: false, blocks: [] };

  blocks.unshift(createBlock("heading2", {
    segments: [{ text: "Ticket Details", fontKey: "F2", color: "#17324d", underline: false }],
  }));

  blocks.push(createBlock("rule"));
  return { pageBreakBefore: false, blocks: blocks };
}

function shouldIncludeAllCustomFields(template) {
  if (!template) return true;
  if (template.custom_fields_mode === "all") return true;
  if (template.custom_fields_mode === "selected") return false;
  if (!Array.isArray(template.visible_custom_fields)) return true;
  return !template.visible_custom_fields.length;
}

function buildCustomFieldsSection(ticket, fieldDefs, template) {
  let blocks = [];
  let customFields = ticket.custom_fields || {};
  let keys = Object.keys(customFields);

  if (!keys.length) return { pageBreakBefore: false, blocks: [] };

  let allowedFields = Array.isArray(template.visible_custom_fields) ? template.visible_custom_fields : [];
  let showAll = shouldIncludeAllCustomFields(template);

  let hasVisible = false;

  blocks.push(createBlock("heading2", {
    segments: [{ text: "Custom Fields", fontKey: "F2", color: "#17324d", underline: false }],
  }));

  keys.forEach(function (key) {
    if (!showAll && allowedFields.indexOf(key) === -1) return;

    let value = customFields[key];
    if (value === null || value === undefined || value === "") return;

    let fieldDef = fieldDefs.find(function (f) { return f.name === key; });
    let label = fieldDef ? fieldDef.label : key.replace(/^cf_/, "").replace(/_/g, " ");

    let displayValue;
    if (typeof value === "boolean") {
      displayValue = value ? "Yes" : "No";
    } else if (Array.isArray(value)) {
      displayValue = value.join(", ");
    } else {
      displayValue = String(value);
    }

    blocks.push(buildDetailFieldBlock(label, displayValue));
    hasVisible = true;
  });

  if (!hasVisible) return { pageBreakBefore: false, blocks: [] };

  blocks.push(createBlock("rule"));
  return { pageBreakBefore: false, blocks: blocks };
}

function buildDescriptionSection(ticket, template, requesterName) {
  let blocks = [];

  blocks.push(createBlock("heading2", {
    segments: [{ text: "Original Request", fontKey: "F2", color: "#17324d", underline: false }],
  }));

  blocks.push(createBlock("meta", {
    segments: [{ text: sanitizePdfText("From: " + requesterName + " | " + formatTicketDate(ticket.created_at, template.date_format || "DD MMM YYYY HH:mm")), fontKey: "F1", color: "#6b7c93", underline: false }],
  }));

  blocks.push(createBlock("rule", { marginTop: 4, marginBottom: 8 }));

  let bodyBlocks = parseHtmlToBlocks(ticket.description);
  if (!bodyBlocks.length) {
    let plainText = ticket.description_text || htmlToPlainText(ticket.description) || "No description provided.";
    bodyBlocks.push(createBlock("paragraph", {
      segments: [{ text: sanitizePdfText(plainText), fontKey: "F1", color: "#284766", underline: false }],
    }));
  }
  blocks.push.apply(blocks, bodyBlocks);

  if (ticket.attachments && ticket.attachments.length) {
    blocks.push(createBlock("meta", {
      marginTop: 8,
      segments: [{ text: sanitizePdfText("Attachments: " + ticket.attachments.map(function (a) { return a.name || "file"; }).join(", ")), fontKey: "F3", color: "#6b7c93", underline: false }],
    }));
  }

  blocks.push(createBlock("rule"));
  return { pageBreakBefore: false, blocks: blocks };
}

function buildConversationsSection(conversations, template, nameCache) {
  let blocks = [];
  let dateFormat = template.date_format || "DD MMM YYYY HH:mm";

  if (!conversations.length) {
    return { pageBreakBefore: false, blocks: [] };
  }

  blocks.push(createBlock("heading2", {
    segments: [{ text: "Conversations (" + conversations.length + ")", fontKey: "F2", color: "#17324d", underline: false }],
  }));

  conversations.forEach(function (conversation, idx) {
    let type = classifyConversation(conversation);
    let userName = nameCache.get(String(conversation.user_id)) || ("User #" + conversation.user_id);

    let headingText;
    if (type === "private_note") {
      headingText = "Private Note by " + userName;
    } else if (type === "public_note") {
      headingText = "Note by " + userName;
    } else if (conversation.incoming) {
      headingText = "Reply from " + userName;
    } else {
      headingText = "Reply by " + userName;
    }

    let headingColor = type === "private_note" ? "#b45309" : "#17324d";

    blocks.push(createBlock("heading3", {
      marginTop: idx > 0 ? 12 : 4,
      segments: [{ text: sanitizePdfText(headingText), fontKey: "F2", color: headingColor, underline: false }],
    }));

    blocks.push(createBlock("meta", {
      segments: [{ text: sanitizePdfText(formatTicketDate(conversation.created_at, dateFormat)), fontKey: "F1", color: "#6b7c93", underline: false }],
    }));

    if (type === "private_note") {
      blocks.push(createBlock("meta", {
        segments: [{ text: "[PRIVATE]", fontKey: "F2", color: "#b45309", underline: false }],
      }));
    }

    blocks.push(createBlock("rule", { marginTop: 4, marginBottom: 6 }));

    let bodyBlocks = parseHtmlToBlocks(conversation.body);
    if (!bodyBlocks.length) {
      let plainText = conversation.body_text || htmlToPlainText(conversation.body) || "No content.";
      bodyBlocks.push(createBlock("paragraph", {
        segments: [{ text: sanitizePdfText(plainText), fontKey: "F1", color: "#284766", underline: false }],
      }));
    }
    blocks.push.apply(blocks, bodyBlocks);

    if (conversation.attachments && conversation.attachments.length) {
      blocks.push(createBlock("meta", {
        marginTop: 4,
        segments: [{ text: sanitizePdfText("Attachments: " + conversation.attachments.map(function (a) { return a.name || "file"; }).join(", ")), fontKey: "F3", color: "#6b7c93", underline: false }],
      }));
    }

    if (idx < conversations.length - 1) {
      blocks.push(createBlock("rule", { marginTop: 8 }));
    }
  });

  return { pageBreakBefore: false, blocks: blocks };
}

function buildTicketPdfSections(ticket, conversations, fieldDefs, template, agentName, requesterName, nameCache) {
  let sectionOrder = template.section_order || DEFAULT_SECTION_ORDER;
  let sections = [];

  sectionOrder.forEach(function (sectionKey) {
    let section;
    switch (sectionKey) {
      case "header":
        section = buildHeaderSection(ticket, template);
        break;
      case "details":
        section = buildDetailsSection(ticket, fieldDefs, template, agentName, requesterName);
        break;
      case "custom_fields":
        section = buildCustomFieldsSection(ticket, fieldDefs, template);
        break;
      case "description":
        if (template.include_description === false) return;
        section = buildDescriptionSection(ticket, template, requesterName);
        break;
      case "conversations":
        section = buildConversationsSection(conversations, template, nameCache);
        break;
      default:
        return;
    }

    if (section && section.blocks.length) {
      sections.push(section);
    }
  });

  if (!sections.length) {
    sections.push({
      pageBreakBefore: false,
      blocks: [
        createBlock("paragraph", {
          segments: [{ text: "No content to display for this ticket.", fontKey: "F1", color: "#284766", underline: false }],
        }),
      ],
    });
  }

  return sections;
}

// ── File name builder ──────────────────────────────────────────────────────────

function buildFileStem(label, timestamp) {
  let stamp = formatDateTime(timestamp).replace(/[^0-9]/g, "").slice(0, 12);
  let slug = normalizeText(label)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);
  let name = slug || "ticket-export";
  return name + "-" + stamp;
}

function buildFileName(label, timestamp) {
  return buildFileStem(label, timestamp) + ".pdf";
}

function buildZipFileName(label, timestamp) {
  return buildFileStem(label, timestamp) + ".zip";
}

function buildBulkZipEntryName(ticket, index) {
  let ticketId = ticket && ticket.id ? Number(ticket.id) : index + 1;
  let subjectSlug = normalizeText(ticket && ticket.subject)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 30);
  let suffix = subjectSlug ? "-" + subjectSlug : "";
  return "ticket-" + padNumber(ticketId, 6) + suffix + ".pdf";
}

function mapExportForClient(record) {
  return {
    id: record.id,
    created_at: record.created_at,
    content_label: record.content_label,
    ticket_id: record.ticket_id || null,
    status: record.status,
    file_name: record.file_name || "",
    mime_type: record.mime_type || "application/pdf",
    download_available: Number(record.chunk_count) > 0,
    error_message: record.error_message || "",
  };
}

async function releaseHistoricalZipPayloads(activeExportId) {
  let items = await readExportIndex();
  let updated = false;
  let nextItems = [];

  for (let index = 0; index < items.length; index += 1) {
    let record = items[index];
    let isZip = normalizeText(record && record.mime_type).toLowerCase() === "application/zip";
    let hasPayload = Number(record && record.chunk_count) > 0;
    let shouldRelease = isZip && hasPayload && record.id !== activeExportId;

    if (shouldRelease) {
      await deleteExportPayload(record);
      nextItems.push(Object.assign({}, record, { chunk_count: 0 }));
      updated = true;
    } else {
      nextItems.push(record);
    }
  }

  if (updated) {
    await writeExportIndex(nextItems);
  }
}

async function tryReleaseHistoricalZipPayloads(activeExportId) {
  try {
    await releaseHistoricalZipPayloads(activeExportId);
  } catch (error) {
    console.error("Failed to release historical ZIP payloads.", {
      export_id: activeExportId,
      detail: buildErrorMessage(error, "Unable to release historical ZIP payloads."),
    });
  }
}

async function tryMarkExportFailed(exportRecord, error, fallbackMessage, appConfig) {
  if (!exportRecord) {
    return;
  }

  let failedRecord = Object.assign({}, exportRecord, {
    status: "failed",
    error_message: buildErrorMessage(error, fallbackMessage),
  });

  try {
    await upsertExportRecord(failedRecord, appConfig);
  } catch (updateError) {
    console.error("Failed to persist export failure state.", {
      export_id: exportRecord.id,
      original_error: buildErrorMessage(error, fallbackMessage),
      update_error: buildErrorMessage(updateError, "Unable to update export state."),
    });
  }
}

// ── Core ticket PDF generation ─────────────────────────────────────────────────

function getTemplateSectionOrder(template) {
  return Array.isArray(template && template.section_order) ? template.section_order : DEFAULT_SECTION_ORDER;
}

function templateIncludesSection(template, sectionKey) {
  return getTemplateSectionOrder(template).indexOf(sectionKey) !== -1;
}

function getTemplateDetailFields(template) {
  return Array.isArray(template && template.visible_detail_fields) ? template.visible_detail_fields : [];
}

function shouldIncludeCustomFieldsForTemplate(template) {
  if (!templateIncludesSection(template, "custom_fields")) return false;
  if (template && template.custom_fields_mode === "selected" && Array.isArray(template.visible_custom_fields)) {
    return template.visible_custom_fields.length > 0;
  }
  return true;
}

function shouldIncludeConversationsForTemplate(template) {
  if (!templateIncludesSection(template, "conversations")) return false;
  return (
    !template ||
    template.include_replies !== false ||
    template.include_public_notes !== false ||
    template.include_private_notes !== false
  );
}

function shouldResolveRequesterNameForTemplate(template) {
  let detailFields = getTemplateDetailFields(template);
  return (
    (templateIncludesSection(template, "description") && (!template || template.include_description !== false)) ||
    (templateIncludesSection(template, "details") && detailFields.indexOf("requester") !== -1)
  );
}

function shouldResolveAgentNameForTemplate(template) {
  let detailFields = getTemplateDetailFields(template);
  return templateIncludesSection(template, "details") && detailFields.indexOf("agent") !== -1;
}

async function fetchFieldDefinitionsForExport(template) {
  if (!shouldIncludeCustomFieldsForTemplate(template)) {
    return [];
  }

  try {
    return await fetchTicketFieldDefinitions();
  } catch (error) {
    console.warn("Unable to load ticket field labels for export. Falling back to raw custom field names.", {
      detail: buildErrorMessage(error, "Unable to load ticket fields."),
    });
    return [];
  }
}

async function buildTicketSectionsForExport(ticketId, template, nameCache, sharedFieldDefs) {
  let ticket = await fetchTicketData(ticketId);
  let shouldFetchConversations = shouldIncludeConversationsForTemplate(template);
  let rawConversations = shouldFetchConversations ? await fetchTicketConversations(ticketId) : [];
  let fieldDefs = Array.isArray(sharedFieldDefs)
    ? sharedFieldDefs
    : await fetchFieldDefinitionsForExport(template);

  let agentName = shouldResolveAgentNameForTemplate(template)
    ? await resolveAgentName(ticket.responder_id, nameCache)
    : "Unassigned";

  let requesterName = "Unknown";
  if (shouldResolveRequesterNameForTemplate(template)) {
    if (ticket.requester && ticket.requester.name) {
      requesterName = ticket.requester.name;
      nameCache.set(String(ticket.requester_id), requesterName);
    } else {
      requesterName = await resolveContactName(ticket.requester_id, nameCache);
    }
  }

  if (shouldFetchConversations) {
    let conversationUserIds = [];
    rawConversations.forEach(function (c) {
      if (c.user_id && !nameCache.has(String(c.user_id))) {
        conversationUserIds.push(c.user_id);
      }
    });

    let uniqueUserIds = Array.from(new Set(conversationUserIds.map(String)));
    await mapInBatches(uniqueUserIds, 3, async function (uid) {
      await resolveUserName(uid, nameCache);
    });
  }

  let filteredConversations = shouldFetchConversations ? filterConversations(rawConversations, template) : [];
  let sections = buildTicketPdfSections(
    ticket, filteredConversations, fieldDefs, template,
    agentName, requesterName, nameCache
  );

  return {
    ticket: ticket,
    sections: sections,
  };
}

async function generateTicketPdf(ticketId, template, nameCache) {
  let resolvedTemplate = template || getDefaultTemplate();
  let result = await buildTicketSectionsForExport(ticketId, resolvedTemplate, nameCache, null);

  let createdAt = Date.now();
  let pdfBinary = buildPdfFromSections(result.sections, createdAt, resolvedTemplate);
  let pdfBase64 = encodeLatin1ToBase64(pdfBinary);

  return {
    ticket: result.ticket,
    pdfBinary: pdfBinary,
    pdfBase64: pdfBase64,
    createdAt: createdAt,
    contentLabel: "Ticket #" + result.ticket.id + " - " + result.ticket.subject,
  };
}

// ── Exported serverless functions ──────────────────────────────────────────────

exports = {

  onSettingsUpdate: function (args) {
    try {
      validateAppSettings(args);
      return renderData();
    } catch (error) {
      return renderData({
        message: "Invalid app settings.",
        detail: buildErrorMessage(error, "Invalid app settings."),
      });
    }
  },

  getTicketPdfDashboardData: async function (args) {
    try {
      let appConfig = resolveAppRuntimeConfig(args);
      let exportsIndex = await markStaleInProgressExports(await readExportIndex());
      return buildResponse({
        success: true,
        limits: {
          bulk_ticket_max: appConfig.maxBulkTickets,
        },
        exports: exportsIndex
          .sort(function (a, b) { return Number(b.created_at || 0) - Number(a.created_at || 0); })
          .map(mapExportForClient),
      });
    } catch (error) {
      return buildErrorResponse("Failed to load print history data.", error);
    }
  },

  createTicketPdfExport: async function (args) {
    let appConfig = resolveAppRuntimeConfig(args);
    let createdAt = Date.now();
    let exportRecord = null;

    try {
      let payload = parseArgs(args);
      let ticketId = payload.ticket_id;
      let shouldPersist = payload.skip_history !== true && payload.persist_export !== false;
      if (!ticketId) {
        throw new Error("ticket_id is required.");
      }

      let template;
      if (payload.template_id) {
        let templates = await readTemplateIndex();
        let found = templates.find(function (t) { return t.id === payload.template_id; });
        template = found || getDefaultTemplate();
      } else if (payload.template && typeof payload.template === "object") {
        template = Object.assign({}, getDefaultTemplate(), payload.template);
      } else {
        template = getDefaultTemplate();
      }

      let exportId = buildExportId();
      if (shouldPersist) {
        exportRecord = {
          id: exportId,
          created_at: createdAt,
          content_label: "Ticket #" + ticketId,
          ticket_id: Number(ticketId),
          status: "in_progress",
          file_name: "",
          mime_type: "application/pdf",
          chunk_count: 0,
          error_message: "",
        };
        await upsertExportRecord(exportRecord, appConfig);
      }

      let nameCache = new Map();
      let result = await generateTicketPdf(ticketId, template, nameCache);

      let chunkCount = 0;
      let outputFileName = buildFileName(result.contentLabel, createdAt);
      if (shouldPersist) {
        chunkCount = await storePdfChunks(exportId, result.pdfBase64);
      }

      if (shouldPersist) {
        exportRecord = Object.assign({}, exportRecord, {
          status: "ready",
          content_label: result.contentLabel,
          file_name: outputFileName,
          mime_type: "application/pdf",
          chunk_count: chunkCount,
        });
        await upsertExportRecord(exportRecord, appConfig);
      }

      return buildResponse({
        success: true,
        export: exportRecord ? mapExportForClient(exportRecord) : null,
        base64_data: result.pdfBase64,
        file_name: outputFileName,
        mime_type: "application/pdf",
      });
    } catch (error) {
      await tryMarkExportFailed(exportRecord, error, "PDF generation failed.", appConfig);
      return buildErrorResponse("Failed to generate the ticket PDF.", error);
    }
  },

  createBulkTicketPdfExport: async function (args) {
    let appConfig = resolveAppRuntimeConfig(args);
    let createdAt = Date.now();
    let exportRecord = null;
    let stage = "init";
    let exportFormat = "pdf";
    let ticketIds = [];

    try {
      stage = "parse_args";
      let payload = parseArgs(args);
      ticketIds = payload.ticket_ids;
      if (!Array.isArray(ticketIds) || !ticketIds.length) {
        throw new Error("ticket_ids array is required.");
      }

      if (ticketIds.length > appConfig.maxBulkTickets) {
        throw new Error("Maximum " + appConfig.maxBulkTickets + " tickets allowed per bulk export.");
      }

      exportFormat = normalizeText(payload.export_format).toLowerCase() === "zip" ? "zip" : "pdf";

      stage = "resolve_template";
      let template;
      if (payload.template_id) {
        let templates = await readTemplateIndex();
        let found = templates.find(function (t) { return t.id === payload.template_id; });
        template = found || getDefaultTemplate();
      } else if (payload.template && typeof payload.template === "object") {
        template = Object.assign({}, getDefaultTemplate(), payload.template);
      } else {
        template = getDefaultTemplate();
      }

      let exportId = buildExportId();
      let ticketLabel = ticketIds.length + " ticket" + (ticketIds.length > 1 ? "s" : "");
      let contentLabel = "Bulk Export: " + ticketLabel + " (#" + ticketIds.slice(0, 5).join(", #") + (ticketIds.length > 5 ? "..." : "") + ")";

      stage = "create_export_record";
      exportRecord = {
        id: exportId,
        created_at: createdAt,
        content_label: contentLabel,
        ticket_id: null,
        status: "in_progress",
        file_name: "",
        mime_type: exportFormat === "zip" ? "application/zip" : "application/pdf",
        chunk_count: 0,
        error_message: "",
      };
      console.info("createBulkTicketPdfExport started", {
        export_id: exportId,
        export_format: exportFormat,
        ticket_count: ticketIds.length,
        ticket_ids: ticketIds,
      });

      let nameCache = new Map();
      let base64Data;
      let outputFileName;

      if (exportFormat === "zip") {
        stage = "build_zip";
        let zipBuilder = createZipBuilder(createdAt);

        for (let i = 0; i < ticketIds.length; i += BULK_BATCH_SIZE) {
          let batch = ticketIds.slice(i, i + BULK_BATCH_SIZE);

          for (let j = 0; j < batch.length; j++) {
            let tid = batch[j];
            try {
              let result = await generateTicketPdf(tid, template, nameCache);
              zipBuilder.appendEntry({
                name: buildBulkZipEntryName(result.ticket, i + j),
                data: result.pdfBinary,
              });
            } catch (ticketError) {
              zipBuilder.appendEntry({
                name: "ticket-" + padNumber(tid, 6) + "-error.txt",
                data: sanitizePdfText("Ticket #" + tid + " failed to export.\n" + buildErrorMessage(ticketError, "Unknown error")),
              });
            }
          }

          if (i + BULK_BATCH_SIZE < ticketIds.length) {
            await sleep(BULK_BATCH_DELAY_MS);
          }
        }

        let zipBinary = zipBuilder.toBinary();
        base64Data = encodeLatin1ToBase64(zipBinary);
        outputFileName = buildZipFileName("bulk-" + ticketIds.length + "-tickets", createdAt);
      } else {
        stage = "build_pdf";
        let allSections = [];
        let sharedFieldDefs = await fetchFieldDefinitionsForExport(template);

        for (let i = 0; i < ticketIds.length; i += BULK_BATCH_SIZE) {
          let batch = ticketIds.slice(i, i + BULK_BATCH_SIZE);

          for (let j = 0; j < batch.length; j++) {
            let tid = batch[j];
            try {
              let result = await buildTicketSectionsForExport(tid, template, nameCache, sharedFieldDefs);
              let ticketSections = result.sections;

              if (allSections.length && ticketSections.length) {
                ticketSections[0].pageBreakBefore = true;
              }
              allSections.push.apply(allSections, ticketSections);
            } catch (ticketError) {
              allSections.push({
                pageBreakBefore: allSections.length > 0,
                blocks: [
                  createBlock("heading2", {
                    segments: [{ text: sanitizePdfText("Ticket #" + tid + " - Error"), fontKey: "F2", color: "#b42318", underline: false }],
                  }),
                  createBlock("paragraph", {
                    segments: [{ text: sanitizePdfText("Failed to load ticket: " + buildErrorMessage(ticketError, "Unknown error")), fontKey: "F1", color: "#b42318", underline: false }],
                  }),
                ],
              });
            }
          }
        }

        let pdfBinary = buildPdfFromSections(allSections, createdAt, template);
        base64Data = encodeLatin1ToBase64(pdfBinary);
        outputFileName = buildFileName("bulk-" + ticketIds.length + "-tickets", createdAt);
      }

      stage = "store_or_finalize";
      let chunkCount = 0;
      if (exportFormat === "zip") {
        await tryReleaseHistoricalZipPayloads(exportId);
      } else {
        chunkCount = await storePdfChunks(exportId, base64Data);
      }

      stage = "mark_ready";
      exportRecord = Object.assign({}, exportRecord, {
        status: "ready",
        file_name: outputFileName,
        mime_type: exportFormat === "zip" ? "application/zip" : "application/pdf",
        chunk_count: chunkCount,
      });
      await upsertExportRecord(exportRecord, appConfig);
      console.info("createBulkTicketPdfExport completed", {
        export_id: exportId,
        export_format: exportFormat,
        ticket_count: ticketIds.length,
        chunk_count: chunkCount,
      });

      return buildResponse({
        success: true,
        export: mapExportForClient(exportRecord),
        base64_data: base64Data,
        file_name: exportRecord.file_name,
        mime_type: exportRecord.mime_type,
      });
    } catch (error) {
      console.error("createBulkTicketPdfExport failed", {
        stage: stage,
        export_id: exportRecord && exportRecord.id,
        export_format: exportFormat,
        ticket_count: Array.isArray(ticketIds) ? ticketIds.length : 0,
        ticket_ids: Array.isArray(ticketIds) ? ticketIds : [],
        detail: buildErrorMessage(error, "Bulk export failed."),
        stack: error && error.stack,
      });
      await tryMarkExportFailed(exportRecord, error, "Bulk export failed.", appConfig);
      return buildErrorResponse("Failed to generate the bulk export file.", error);
    }
  },

  recordBulkZipExportHistory: async function (args) {
    try {
      let appConfig = resolveAppRuntimeConfig(args);
      let payload = parseArgs(args);
      let ticketIds = payload.ticket_ids;
      if (!Array.isArray(ticketIds) || !ticketIds.length) {
        throw new Error("ticket_ids array is required.");
      }

      if (ticketIds.length > appConfig.maxBulkTickets) {
        throw new Error("Maximum " + appConfig.maxBulkTickets + " tickets allowed per bulk export.");
      }

      let createdAt = Date.now();
      let failedCount = Math.min(ticketIds.length, Math.max(0, Number(payload.failed_count) || 0));
      let ticketLabel = ticketIds.length + " ticket" + (ticketIds.length > 1 ? "s" : "");
      let contentLabel = "Bulk ZIP Export: " + ticketLabel + " (#" + ticketIds.slice(0, 5).join(", #") + (ticketIds.length > 5 ? "..." : "") + ")";
      let exportRecord = {
        id: buildExportId(),
        created_at: createdAt,
        content_label: contentLabel,
        ticket_id: null,
        status: failedCount >= ticketIds.length ? "failed" : "ready",
        file_name: normalizeText(payload.file_name) || buildZipFileName("bulk-" + ticketIds.length + "-tickets", createdAt),
        mime_type: "application/zip",
        chunk_count: 0,
        error_message: failedCount > 0
          ? failedCount + " of " + ticketIds.length + " tickets failed. The downloaded ZIP contains error files."
          : "",
      };

      await upsertExportRecord(exportRecord, appConfig);

      return buildResponse({
        success: true,
        export: mapExportForClient(exportRecord),
      });
    } catch (error) {
      return buildErrorResponse("Failed to record the ZIP export in print history.", error);
    }
  },

  recordClientBulkExportHistory: async function (args) {
    try {
      let appConfig = resolveAppRuntimeConfig(args);
      let payload = parseArgs(args);
      let ticketIds = payload.ticket_ids;
      if (!Array.isArray(ticketIds) || !ticketIds.length) {
        throw new Error("ticket_ids array is required.");
      }

      if (ticketIds.length > appConfig.maxBulkTickets) {
        throw new Error("Maximum " + appConfig.maxBulkTickets + " tickets allowed per bulk export.");
      }

      let exportFormat = normalizeText(payload.export_format).toLowerCase() === "zip" ? "zip" : "pdf";
      let createdAt = Date.now();
      let failedCount = Math.min(ticketIds.length, Math.max(0, Number(payload.failed_count) || 0));
      let ticketLabel = ticketIds.length + " ticket" + (ticketIds.length > 1 ? "s" : "");
      let labelPrefix = exportFormat === "zip" ? "Bulk ZIP Export: " : "Bulk PDF Export: ";
      let contentLabel = labelPrefix + ticketLabel + " (#" + ticketIds.slice(0, 5).join(", #") + (ticketIds.length > 5 ? "..." : "") + ")";
      let exportRecord = {
        id: buildExportId(),
        created_at: createdAt,
        content_label: contentLabel,
        ticket_id: null,
        status: failedCount >= ticketIds.length ? "failed" : "ready",
        file_name: normalizeText(payload.file_name) || (exportFormat === "zip"
          ? buildZipFileName("bulk-" + ticketIds.length + "-tickets", createdAt)
          : buildFileName("bulk-" + ticketIds.length + "-tickets", createdAt)),
        mime_type: exportFormat === "zip" ? "application/zip" : "application/pdf",
        chunk_count: 0,
        error_message: failedCount > 0
          ? failedCount + " of " + ticketIds.length + " tickets failed. The downloaded " + exportFormat.toUpperCase() + " contains error details."
          : "",
      };

      await upsertExportRecord(exportRecord, appConfig);

      return buildResponse({
        success: true,
        export: mapExportForClient(exportRecord),
      });
    } catch (error) {
      return buildErrorResponse("Failed to record the bulk export in print history.", error);
    }
  },

  getTicketPdfDownload: async function (args) {
    try {
      let payload = parseArgs(args);
      let exportId = normalizeText(payload.export_id);
      if (!exportId) {
        throw new Error("export_id is required.");
      }

      let exportsIndex = await readExportIndex();
      let record = exportsIndex.find(function (item) { return item.id === exportId; });
      if (!record) {
        throw new Error("Export not found.");
      }
      if (record.status !== "ready") {
        throw new Error("This export is not ready for download yet.");
      }

      let pdfBase64 = await readPdfChunks(record);
      if (!pdfBase64) {
        if (normalizeText(record.mime_type).toLowerCase() === "application/zip") {
          throw new Error("This ZIP is no longer cached in print history. Please export it again.");
        }
        throw new Error("Stored PDF data is unavailable.");
      }

      return buildResponse({
        success: true,
        export_id: record.id,
        file_name: record.file_name || "ticket-export.pdf",
        mime_type: record.mime_type || "application/pdf",
        base64_data: pdfBase64,
      });
    } catch (error) {
      return buildErrorResponse("Failed to load the PDF.", error);
    }
  },

  searchTickets: async function (args) {
    try {
      let payload = parseArgs(args);
      let filters = payload.filters || {};
      let page = Number(payload.page) || 1;

      validateSearchFilters(filters);
      let result = await searchTicketsQuery(filters, page);

      let tickets = (result.tickets || []).map(function (t) {
        return {
          id: t.id,
          subject: normalizeText(t.subject) || ("Ticket #" + t.id),
          status: t.status,
          priority: t.priority,
          type: normalizeText(t.type),
          requester_id: t.requester_id,
          created_at: t.created_at || "",
          updated_at: t.updated_at || "",
          status_label: resolveStatusLabel(t.status),
          priority_label: resolvePriorityLabel(t.priority),
        };
      });

      return buildResponse({
        success: true,
        total: result.total || tickets.length,
        tickets: tickets,
        page: page,
      });
    } catch (error) {
      let parsedArgs = parseArgs(args);
      let filters = parsedArgs.filters || {};
      let page = Number(parsedArgs.page) || 1;
      let errorDetail = buildErrorMessage(error, "Failed to search tickets.");
      let debugParts = [];
      if (error && error.queryString) {
        debugParts.push("query=" + error.queryString);
      }
      if (error && error.encodedQuery) {
        debugParts.push("encodedQuery=" + error.encodedQuery);
      }
      if (error && error.status) {
        debugParts.push("status=" + error.status);
      }

      console.error("searchTickets handler failed", {
        filters: filters,
        page: page,
        status: error && error.status,
        message: error && error.message,
        detail: errorDetail,
        response: error && (error.response || error.responseText || error.body || ""),
        headers: error && error.headers,
        stack: error && error.stack,
      });

      return buildResponse({
        success: false,
        message: "Failed to search tickets.",
        detail: debugParts.length ? errorDetail + " | " + debugParts.join(" | ") : errorDetail,
      });
    }
  },

  saveTemplate: async function (args) {
    try {
      let appConfig = resolveAppRuntimeConfig(args);
      let payload = parseArgs(args);
      let templateData = payload.template;
      if (!templateData || typeof templateData !== "object") {
        throw new Error("Template data is required.");
      }

      let templates = await readTemplateIndex();
      let now = Date.now();

      if (templateData.id) {
        let index = templates.findIndex(function (t) { return t.id === templateData.id; });
        if (index === -1) {
          throw new Error("Template not found for update.");
        }
        templates[index] = Object.assign({}, templates[index], templateData, { updated_at: now });
      } else {
        if (templates.length >= appConfig.maxTemplates) {
          throw new Error("Maximum " + appConfig.maxTemplates + " templates allowed. Delete an existing template first.");
        }
        templateData.id = "tpl_" + buildExportId();
        templateData.created_at = now;
        templateData.updated_at = now;
        templates.push(templateData);
      }

      await writeTemplateIndex(templates);

      return buildResponse({
        success: true,
        template: templateData,
      });
    } catch (error) {
      return buildErrorResponse("Failed to save template.", error);
    }
  },

  listTemplates: async function () {
    try {
      let templates = await readTemplateIndex();
      return buildResponse({
        success: true,
        templates: templates,
      });
    } catch (error) {
      return buildErrorResponse("Failed to load templates.", error);
    }
  },

  deleteTemplate: async function (args) {
    try {
      let payload = parseArgs(args);
      let templateId = normalizeText(payload.template_id);
      if (!templateId) {
        throw new Error("template_id is required.");
      }

      let templates = await readTemplateIndex();
      let filtered = templates.filter(function (t) { return t.id !== templateId; });

      if (filtered.length === templates.length) {
        throw new Error("Template not found.");
      }

      await writeTemplateIndex(filtered);

      return buildResponse({ success: true });
    } catch (error) {
      return buildErrorResponse("Failed to delete template.", error);
    }
  },

  getTicketFieldDefinitions: async function () {
    try {
      let fieldDefs = await fetchTicketFieldDefinitions();
      return buildResponse({
        success: true,
        fields: fieldDefs,
      });
    } catch (error) {
      return buildErrorResponse("Failed to load ticket field definitions.", error);
    }
  },
};
